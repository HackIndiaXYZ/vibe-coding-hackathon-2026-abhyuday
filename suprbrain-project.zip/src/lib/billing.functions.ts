import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { PLAN_LIMITS, type Feature, type Plan } from "./billing";

function monthBounds(now = new Date()) {
  const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const end = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));
  return { start, end };
}

function periodStartDate(d = new Date()) {
  // YYYY-MM-01
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-01`;
}

async function getOrCreateSubscription(userId: string) {
  const { data: existing } = await supabaseAdmin
    .from("subscriptions")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();

  const { start, end } = monthBounds();

  if (!existing) {
    const { data: inserted } = await supabaseAdmin
      .from("subscriptions")
      .insert({
        user_id: userId,
        plan: "free",
        current_period_start: start.toISOString(),
        current_period_end: end.toISOString(),
      })
      .select("*")
      .single();
    return inserted!;
  }

  // Auto-reset period if expired (free auto-renews monthly)
  if (new Date(existing.current_period_end) <= new Date()) {
    const { data: updated } = await supabaseAdmin
      .from("subscriptions")
      .update({
        current_period_start: start.toISOString(),
        current_period_end: end.toISOString(),
      })
      .eq("user_id", userId)
      .select("*")
      .single();
    return updated!;
  }

  return existing;
}

async function getUsageMap(userId: string) {
  const period = periodStartDate();
  const { data } = await supabaseAdmin
    .from("usage_counters")
    .select("feature, count")
    .eq("user_id", userId)
    .eq("period_start", period);

  const map: Record<Feature, number> = { debate: 0, deck: 0, revenue: 0 };
  (data ?? []).forEach((r) => {
    map[r.feature as Feature] = r.count;
  });
  return map;
}

export const getBillingStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const userId = context.userId;
    const sub = await getOrCreateSubscription(userId);
    const usage = await getUsageMap(userId);
    const plan = sub.plan as Plan;
    return {
      plan,
      currentPeriodStart: sub.current_period_start,
      currentPeriodEnd: sub.current_period_end,
      limits: PLAN_LIMITS[plan],
      usage,
    };
  });

export const consumeFeature = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ feature: z.enum(["debate", "deck", "revenue"]) }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const userId = context.userId;
    const sub = await getOrCreateSubscription(userId);
    const plan = sub.plan as Plan;
    const limit = PLAN_LIMITS[plan][data.feature];
    const period = periodStartDate();

    // Read current count
    const { data: row } = await supabaseAdmin
      .from("usage_counters")
      .select("count")
      .eq("user_id", userId)
      .eq("period_start", period)
      .eq("feature", data.feature)
      .maybeSingle();

    const current = row?.count ?? 0;

    if (limit !== null && current >= limit) {
      return {
        ok: false as const,
        plan,
        limit,
        used: current,
        resetAt: sub.current_period_end,
      };
    }

    // Upsert increment
    const next = current + 1;
    await supabaseAdmin
      .from("usage_counters")
      .upsert(
        {
          user_id: userId,
          period_start: period,
          feature: data.feature,
          count: next,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "user_id,period_start,feature" },
      );

    return { ok: true as const, plan, limit, used: next, resetAt: sub.current_period_end };
  });
