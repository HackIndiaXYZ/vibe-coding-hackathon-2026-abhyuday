import { createOpenAICompatible } from "@ai-sdk/openai-compatible";

export const createLovableAiGatewayProvider = (lovableApiKey: string) =>
  createOpenAICompatible({
    name: "lovable",
    baseURL: "https://ai.gateway.lovable.dev/v1",
    headers: {
      "Lovable-API-Key": lovableApiKey,
      "X-Lovable-AIG-SDK": "vercel-ai-sdk",
    },
  });

export type Persona = {
  id: "gemini" | "gpt" | "claude";
  name: string;
  model: string;
  systemTrait: string;
  color: string;
};

export const PERSONAS: Persona[] = [
  {
    id: "gemini",
    name: "Gemini",
    model: "google/gemini-3-flash-preview",
    systemTrait:
      "You are the OPTIMIST. You see opportunity, market timing, and upside. Argue for boldness and speed, but ground every claim in real startup logic. Be sharp, not fluffy.",
    color: "var(--gemini)",
  },
  {
    id: "gpt",
    name: "GPT-5",
    model: "openai/gpt-5",
    systemTrait:
      "You are the STRATEGIST. You think in unit economics, defensibility, distribution, and second-order effects. Push back hard when reasoning is sloppy. Cite frameworks when useful.",
    color: "var(--gpt)",
  },
  {
    id: "claude",
    name: "Claude",
    model: "openai/gpt-5.4",
    systemTrait:
      "You are the SKEPTIC. You hunt for hidden risks, failure modes, and false assumptions. Steelman the opposing view, then point out what could break. Be precise and direct.",
    color: "var(--claude)",
  },
];
