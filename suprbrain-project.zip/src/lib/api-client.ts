import { supabase } from "@/integrations/supabase/client";
import { PLAN_LABEL, FEATURE_LABEL, type Feature, type Plan } from "./billing";

export async function authedFetch(input: string, init: RequestInit = {}) {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  const headers = new Headers(init.headers ?? {});
  headers.set("Content-Type", "application/json");
  if (token) headers.set("Authorization", `Bearer ${token}`);
  return fetch(input, { ...init, headers });
}

export async function handleQuotaResponse(res: Response, feature: Feature): Promise<string | null> {
  if (res.status !== 402) return null;
  try {
    const body = (await res.json()) as { plan: Plan; limit: number; resetAt: string };
    const resetDate = new Date(body.resetAt).toLocaleDateString(undefined, {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
    return `Your ${PLAN_LABEL[body.plan]} plan limit of ${body.limit} ${FEATURE_LABEL[feature]} this month has been reached. Limits reset on ${resetDate} — or upgrade for more.`;
  } catch {
    return "Plan limit reached. Please upgrade to continue.";
  }
}
