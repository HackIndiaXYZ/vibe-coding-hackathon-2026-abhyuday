import { createClient } from "@supabase/supabase-js";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import type { Database } from "@/integrations/supabase/types";
import { PLAN_LIMITS, type Feature, type Plan } from "./billing";

export type AuthResult =
  | { ok: true; userId: string }
  | { ok: false; response: Response };

export async function requireUser(request: Request): Promise<AuthResult> {
  const authHeader = request.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return { ok: false, response: new Response("Unauthorized", { status: 401 }) };
  }
  const token = authHeader.slice("Bearer ".length).trim();
  if (!token) {
    return { ok: false, response: new Response("Unauthorized", { status: 401 }) };
  }

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_PUBLISHABLE_KEY = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) {
    return { ok: false, response: new Response("Server misconfigured", { status: 500 }) };
  }

  const client = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
  const { data, error } = await client.auth.getClaims(token);
  if (error || !data?.claims?.sub) {
    return { ok: false, response: new Response("Unauthorized", { status: 401 }) };
  }
  return { ok: true, userId: data.claims.sub as string };
}

function monthBounds(now = new Date()) {
  const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const end = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));
  return { start, end };
}

function periodStartDate(d = new Date()) {
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-01`;
}

async function getOrCreateSubscription(userId: string) {
  const { data: existing } = await supabaseAdmin
    .from("subscriptions")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();
  const { start, end } = monthBounds();
  if (!existing) {
    const { data: inserted } = await supabaseAdmin
      .from("subscriptions")
      .insert({
        user_id: userId,
        plan: "free",
        current_period_start: start.toISOString(),
        current_period_end: end.toISOString(),
      })
      .select("*")
      .single();
    return inserted!;
  }
  if (new Date(existing.current_period_end) <= new Date()) {
    const { data: updated } = await supabaseAdmin
      .from("subscriptions")
      .update({
        current_period_start: start.toISOString(),
        current_period_end: end.toISOString(),
      })
      .eq("user_id", userId)
      .select("*")
      .single();
    return updated!;
  }
  return existing;
}

export async function consumeOrReject(
  userId: string,
  feature: Feature,
): Promise<{ ok: true } | { ok: false; response: Response }> {
  const sub = await getOrCreateSubscription(userId);
  const plan = sub.plan as Plan;
  const limit = PLAN_LIMITS[plan][feature];
  const period = periodStartDate();

  const { data: row } = await supabaseAdmin
    .from("usage_counters")
    .select("count")
    .eq("user_id", userId)
    .eq("period_start", period)
    .eq("feature", feature)
    .maybeSingle();
  const current = row?.count ?? 0;

  if (limit !== null && current >= limit) {
    return {
      ok: false,
      response: new Response(
        JSON.stringify({
          error: "plan_limit_reached",
          plan,
          limit,
          used: current,
          resetAt: sub.current_period_end,
        }),
        { status: 402, headers: { "content-type": "application/json" } },
      ),
    };
  }

  await supabaseAdmin.from("usage_counters").upsert(
    {
      user_id: userId,
      period_start: period,
      feature,
      count: current + 1,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "user_id,period_start,feature" },
  );
  return { ok: true };
}
