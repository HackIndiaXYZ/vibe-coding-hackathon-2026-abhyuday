export async function parseFileToText(file: File): Promise<string> {
  const name = file.name.toLowerCase();
  let text = "";
  if (name.endsWith(".pdf")) {
    const pdfjs = await import("pdfjs-dist");
    const workerSrc = (await import("pdfjs-dist/build/pdf.worker.min.mjs?url")).default;
    pdfjs.GlobalWorkerOptions.workerSrc = workerSrc;
    const buf = await file.arrayBuffer();
    const pdf = await pdfjs.getDocument({ data: buf }).promise;
    const parts: string[] = [];
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      parts.push(content.items.map((it) => ("str" in it ? it.str : "")).join(" "));
    }
    text = parts.join("\n\n");
  } else if (name.endsWith(".docx")) {
    const mammoth = await import("mammoth");
    const buf = await file.arrayBuffer();
    const res = await mammoth.extractRawText({ arrayBuffer: buf });
    text = res.value;
  } else if (name.endsWith(".doc")) {
    throw new Error("Legacy .doc files aren't supported. Please save as .docx or .pdf.");
  } else {
    text = await file.text();
  }
  return text.replace(/\s+\n/g, "\n").trim();
}
