export type Plan = "free" | "pro" | "max";
export type Feature = "debate" | "deck" | "revenue";

// null = unlimited
export const PLAN_LIMITS: Record<Plan, Record<Feature, number | null>> = {
  free: { debate: 3, deck: 1, revenue: 1 },
  pro: { debate: 10, deck: 5, revenue: 3 },
  max: { debate: null, deck: null, revenue: 5 },
};

export const PLAN_LABEL: Record<Plan, string> = {
  free: "Free",
  pro: "Pro",
  max: "Scale",
};

export const FEATURE_LABEL: Record<Feature, string> = {
  debate: "decision debates",
  deck: "pitch decks",
  revenue: "revenue projections",
};
