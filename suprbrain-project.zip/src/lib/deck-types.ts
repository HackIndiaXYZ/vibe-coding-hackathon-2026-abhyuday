export type Slide = { title: string; subtitle?: string; bullets: string[] };

export type TemplateId = "midnight" | "editorial" | "brutalist" | "pastel";

export type DeckTemplate = {
  id: TemplateId;
  name: string;
  description: string;
  // Hex without leading # (used by pptxgenjs)
  coverBg: string;
  coverFg: string;
  coverMuted: string;
  slideBg: string;
  slideFg: string;
  slideMuted: string;
  accent: string;
  // Web font stacks for preview; first family name is used by exports
  headingFont: string;
  bodyFont: string;
  // Visual variant — drives accent treatment (bullet glyph, header rule, etc.)
  variant: "minimal" | "editorial" | "brutalist" | "playful";
  bullet: string;
};

export type Deck = {
  company: string;
  tagline: string;
  slides: Slide[];
  templateId?: TemplateId;
};

export const TEMPLATES: Record<TemplateId, DeckTemplate> = {
  midnight: {
    id: "midnight",
    name: "Midnight",
    description: "Dark, premium, amber accent. The default investor deck.",
    coverBg: "0A0A0A",
    coverFg: "FFFFFF",
    coverMuted: "9CA3AF",
    slideBg: "FFFFFF",
    slideFg: "111111",
    slideMuted: "6B7280",
    accent: "F5B400",
    headingFont: "Helvetica",
    bodyFont: "Helvetica",
    variant: "minimal",
    bullet: "→",
  },
  editorial: {
    id: "editorial",
    name: "Editorial",
    description: "Cream + serif. Reads like a magazine feature.",
    coverBg: "1B1A17",
    coverFg: "F5EFE0",
    coverMuted: "C9B68B",
    slideBg: "F5EFE0",
    slideFg: "1B1A17",
    slideMuted: "8A7B5C",
    accent: "8A1E1E",
    headingFont: "Georgia",
    bodyFont: "Georgia",
    variant: "editorial",
    bullet: "—",
  },
  brutalist: {
    id: "brutalist",
    name: "Brutalist",
    description: "Stark white, massive type, hot red accent.",
    coverBg: "FFFFFF",
    coverFg: "000000",
    coverMuted: "555555",
    slideBg: "FFFFFF",
    slideFg: "000000",
    slideMuted: "555555",
    accent: "FF3B30",
    headingFont: "Impact",
    bodyFont: "Courier New",
    variant: "brutalist",
    bullet: "▸",
  },
  pastel: {
    id: "pastel",
    name: "Pastel",
    description: "Soft pastel, friendly, modern consumer pitch.",
    coverBg: "FCE7F3",
    coverFg: "1F1147",
    coverMuted: "6D4C9F",
    slideBg: "FFF7F0",
    slideFg: "1F1147",
    slideMuted: "7D6F9E",
    accent: "7C3AED",
    headingFont: "Trebuchet MS",
    bodyFont: "Trebuchet MS",
    variant: "playful",
    bullet: "✦",
  },
};

export function getTemplate(id?: TemplateId): DeckTemplate {
  return TEMPLATES[id ?? "midnight"] ?? TEMPLATES.midnight;
}
