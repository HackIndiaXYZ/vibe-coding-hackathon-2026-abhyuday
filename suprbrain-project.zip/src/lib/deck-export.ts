import { getTemplate, type Deck, type DeckTemplate } from "./deck-types";

function hexToRgb(hex: string): [number, number, number] {
  const m = hex.replace("#", "").padEnd(6, "0");
  return [
    parseInt(m.slice(0, 2), 16),
    parseInt(m.slice(2, 4), 16),
    parseInt(m.slice(4, 6), 16),
  ];
}

export async function downloadDeckPptx(deck: Deck) {
  const t = getTemplate(deck.templateId);
  const PptxGenJS = (await import("pptxgenjs")).default;
  const pres = new PptxGenJS();
  pres.layout = "LAYOUT_WIDE"; // 13.33 x 7.5 in
  pres.title = deck.company;

  // Cover
  const cover = pres.addSlide();
  cover.background = { color: t.coverBg };
  // Accent rule on cover
  cover.addShape("rect", {
    x: 0.6, y: 2.0, w: 0.6, h: 0.08, fill: { color: t.accent }, line: { color: t.accent },
  });
  cover.addText(deck.company, {
    x: 0.6, y: 2.2, w: 12, h: 1.6,
    fontSize: t.variant === "brutalist" ? 84 : 60,
    bold: true, color: t.coverFg, fontFace: t.headingFont,
    charSpacing: t.variant === "brutalist" ? -2 : 0,
  });
  cover.addText(deck.tagline, {
    x: 0.6, y: t.variant === "brutalist" ? 4.0 : 3.8, w: 12, h: 0.8,
    fontSize: 24, color: t.coverMuted, fontFace: t.bodyFont,
    italic: t.variant === "editorial",
  });
  cover.addText(t.name.toUpperCase(), {
    x: 0.6, y: 6.9, w: 6, h: 0.3,
    fontSize: 10, color: t.coverMuted, fontFace: t.bodyFont, charSpacing: 6,
  });

  deck.slides.forEach((s, i) => {
    const slide = pres.addSlide();
    slide.background = { color: t.slideBg };

    // Header rule for editorial / brutalist
    if (t.variant === "editorial" || t.variant === "brutalist") {
      slide.addShape("rect", {
        x: 0.6, y: 0.85, w: 12, h: t.variant === "brutalist" ? 0.04 : 0.015,
        fill: { color: t.variant === "brutalist" ? t.accent : t.slideFg },
        line: { color: t.variant === "brutalist" ? t.accent : t.slideFg },
      });
    }

    slide.addText(
      `${String(i + 1).padStart(2, "0")}  /  ${deck.company}`,
      {
        x: 0.6, y: 0.4, w: 8, h: 0.35,
        fontSize: 11, color: t.slideMuted, fontFace: t.bodyFont, charSpacing: 4,
      },
    );
    slide.addText(t.name.toUpperCase(), {
      x: 8.6, y: 0.4, w: 4, h: 0.35,
      fontSize: 11, color: t.accent, fontFace: t.bodyFont, charSpacing: 4, align: "right",
    });

    slide.addText(s.title, {
      x: 0.6, y: 1.1, w: 12, h: 1.4,
      fontSize: t.variant === "brutalist" ? 48 : 36,
      bold: true, color: t.slideFg, fontFace: t.headingFont,
    });

    if (s.subtitle) {
      slide.addText(s.subtitle, {
        x: 0.6, y: 2.4, w: 12, h: 0.6,
        fontSize: 18, color: t.slideMuted, fontFace: t.bodyFont,
        italic: t.variant === "editorial",
      });
    }

    slide.addText(
      s.bullets.map((b) => ({
        text: b,
        options: { color: t.slideFg, bullet: { characterCode: bulletCharCode(t.bullet) } },
      })),
      {
        x: 0.6, y: s.subtitle ? 3.2 : 2.8, w: 12, h: 3.6,
        fontSize: 18, color: t.slideFg, fontFace: t.bodyFont, paraSpaceAfter: 10,
      },
    );

    slide.addText(deck.tagline, {
      x: 0.6, y: 6.9, w: 12, h: 0.3,
      fontSize: 10, color: t.slideMuted, fontFace: t.bodyFont,
    });
  });

  await pres.writeFile({ fileName: `${safeName(deck.company)}-${t.id}-deck.pptx` });
}

// pptxgenjs accepts a hex unicode code point for bullets
function bulletCharCode(glyph: string): string {
  return glyph.codePointAt(0)!.toString(16).toUpperCase().padStart(4, "0");
}

export async function downloadDeckDocx(deck: Deck) {
  const t = getTemplate(deck.templateId);
  const docx = await import("docx");
  const {
    Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
    PageBreak, LevelFormat,
  } = docx;

  const children: InstanceType<typeof Paragraph>[] = [];

  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 2400, after: 200 },
      children: [
        new TextRun({
          text: deck.company, bold: true, size: t.variant === "brutalist" ? 96 : 72,
          font: t.headingFont, color: t.coverFg === "FFFFFF" ? "111111" : t.coverFg,
        }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
      children: [
        new TextRun({
          text: deck.tagline, italics: t.variant === "editorial", size: 28,
          color: t.slideMuted, font: t.bodyFont,
        }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
      children: [
        new TextRun({ text: t.name.toUpperCase(), size: 18, color: t.accent, font: t.bodyFont, characterSpacing: 60 }),
      ],
    }),
    new Paragraph({ children: [new PageBreak()] }),
  );

  deck.slides.forEach((s, i) => {
    children.push(
      new Paragraph({
        spacing: { after: 120 },
        children: [
          new TextRun({
            text: `${String(i + 1).padStart(2, "0")} / ${deck.company.toUpperCase()}`,
            color: t.slideMuted, size: 18, font: t.bodyFont,
          }),
        ],
      }),
      new Paragraph({
        heading: HeadingLevel.HEADING_1,
        spacing: { after: 120 },
        children: [
          new TextRun({
            text: s.title, bold: true,
            size: t.variant === "brutalist" ? 56 : 44,
            font: t.headingFont, color: t.slideFg,
          }),
        ],
      }),
    );
    if (s.subtitle) {
      children.push(
        new Paragraph({
          spacing: { after: 200 },
          children: [
            new TextRun({
              text: s.subtitle, color: t.slideMuted, size: 24,
              font: t.bodyFont, italics: t.variant === "editorial",
            }),
          ],
        }),
      );
    }
    s.bullets.forEach((b) => {
      children.push(
        new Paragraph({
          numbering: { reference: "deck-bullets", level: 0 },
          spacing: { after: 100 },
          children: [new TextRun({ text: b, size: 24, font: t.bodyFont, color: t.slideFg })],
        }),
      );
    });
    if (i < deck.slides.length - 1) {
      children.push(new Paragraph({ children: [new PageBreak()] }));
    }
  });

  const doc = new Document({
    numbering: {
      config: [
        {
          reference: "deck-bullets",
          levels: [
            {
              level: 0,
              format: LevelFormat.BULLET,
              text: t.bullet,
              alignment: AlignmentType.LEFT,
              style: {
                run: { color: t.accent, font: t.bodyFont },
                paragraph: { indent: { left: 720, hanging: 360 } },
              },
            },
          ],
        },
      ],
    },
    sections: [{ children }],
  });

  const blob = await Packer.toBlob(doc);
  triggerDownload(blob, `${safeName(deck.company)}-${t.id}-deck.docx`);
}

export async function downloadDeckPdf(deck: Deck) {
  const t = getTemplate(deck.templateId);
  const { jsPDF } = await import("jspdf");
  const pdf = new jsPDF({ orientation: "landscape", unit: "pt", format: [960, 540] });
  const W = 960;
  const H = 540;

  const pdfFont = (font: string): "helvetica" | "times" | "courier" => {
    const f = font.toLowerCase();
    if (f.includes("georgia") || f.includes("times") || f.includes("serif")) return "times";
    if (f.includes("courier") || f.includes("mono")) return "courier";
    return "helvetica";
  };
  const headFont = pdfFont(t.headingFont);
  const bodFont = pdfFont(t.bodyFont);

  const [cbgR, cbgG, cbgB] = hexToRgb(t.coverBg);
  const [cfgR, cfgG, cfgB] = hexToRgb(t.coverFg);
  const [cmR, cmG, cmB] = hexToRgb(t.coverMuted);
  const [aR, aG, aB] = hexToRgb(t.accent);
  const [sbgR, sbgG, sbgB] = hexToRgb(t.slideBg);
  const [sfgR, sfgG, sfgB] = hexToRgb(t.slideFg);
  const [smR, smG, smB] = hexToRgb(t.slideMuted);

  // Cover
  pdf.setFillColor(cbgR, cbgG, cbgB);
  pdf.rect(0, 0, W, H, "F");
  pdf.setFillColor(aR, aG, aB);
  pdf.rect(60, 200, 40, 4, "F");
  pdf.setTextColor(cfgR, cfgG, cfgB);
  pdf.setFont(headFont, "bold");
  pdf.setFontSize(t.variant === "brutalist" ? 64 : 48);
  pdf.text(deck.company, 60, 260);
  pdf.setFont(bodFont, t.variant === "editorial" ? "italic" : "normal");
  pdf.setFontSize(20);
  pdf.setTextColor(cmR, cmG, cmB);
  pdf.text(deck.tagline, 60, 300);
  pdf.setFont(bodFont, "normal");
  pdf.setFontSize(10);
  pdf.text(t.name.toUpperCase(), 60, H - 30);

  deck.slides.forEach((s, i) => {
    pdf.addPage([960, 540], "landscape");
    pdf.setFillColor(sbgR, sbgG, sbgB);
    pdf.rect(0, 0, W, H, "F");

    // Header rule
    if (t.variant === "brutalist") {
      pdf.setFillColor(aR, aG, aB);
      pdf.rect(60, 70, W - 120, 3, "F");
    } else if (t.variant === "editorial") {
      pdf.setDrawColor(sfgR, sfgG, sfgB);
      pdf.setLineWidth(0.5);
      pdf.line(60, 70, W - 60, 70);
    }

    pdf.setFont(bodFont, "normal");
    pdf.setFontSize(10);
    pdf.setTextColor(smR, smG, smB);
    pdf.text(
      `${String(i + 1).padStart(2, "0")}  /  ${deck.company.toUpperCase()}`,
      60, 50,
    );
    pdf.setTextColor(aR, aG, aB);
    pdf.text(t.name.toUpperCase(), W - 60, 50, { align: "right" });

    pdf.setTextColor(sfgR, sfgG, sfgB);
    pdf.setFont(headFont, "bold");
    pdf.setFontSize(t.variant === "brutalist" ? 40 : 32);
    const titleLines = pdf.splitTextToSize(s.title, W - 120);
    pdf.text(titleLines, 60, 130);
    let y = 130 + titleLines.length * (t.variant === "brutalist" ? 44 : 36);

    if (s.subtitle) {
      pdf.setFont(bodFont, t.variant === "editorial" ? "italic" : "normal");
      pdf.setFontSize(16);
      pdf.setTextColor(smR, smG, smB);
      const subLines = pdf.splitTextToSize(s.subtitle, W - 120);
      pdf.text(subLines, 60, y + 10);
      y += subLines.length * 22 + 10;
    }

    pdf.setFont(bodFont, "normal");
    pdf.setFontSize(16);
    y += 24;
    s.bullets.forEach((b) => {
      const lines = pdf.splitTextToSize(b, W - 160);
      pdf.setTextColor(aR, aG, aB);
      pdf.text(t.bullet, 60, y);
      pdf.setTextColor(sfgR, sfgG, sfgB);
      pdf.text(lines, 90, y);
      y += lines.length * 22 + 6;
    });

    // Footer tagline
    pdf.setFont(bodFont, "normal");
    pdf.setFontSize(9);
    pdf.setTextColor(smR, smG, smB);
    pdf.text(deck.tagline, 60, H - 25);
  });

  pdf.save(`${safeName(deck.company)}-${getTemplate(deck.templateId).id}-deck.pdf`);
}

function safeName(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "deck";
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export type { DeckTemplate };
