import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, Check, Brain, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const UPGRADE_BASE = "https://rzp.io/rzp/xUl35I2";

function buildUpgradeUrl(plan: "pro" | "max", userId: string | null, email: string | null) {
  if (!userId) return UPGRADE_BASE;
  const params = new URLSearchParams();
  params.set("notes[user_id]", userId);
  params.set("notes[plan]", plan);
  if (email) params.set("prefill[email]", email);
  return `${UPGRADE_BASE}?${params.toString()}`;
}

export const Route = createFileRoute("/pricing")({
  validateSearch: (search: Record<string, unknown>) => ({
    from: typeof search.from === "string" ? search.from : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Pricing — Suprbrain" },
      { name: "description", content: "Simple plans for your AI boardroom. Debates, pitch decks, and revenue projections." },
      { property: "og:title", content: "Pricing — Suprbrain" },
      { property: "og:description", content: "Simple plans for your AI boardroom." },
    ],
  }),
  component: PricingPage,
});

type Currency = { code: string; symbol: string; rate: number; country: string };

// USD base rates (approx, updated periodically)
const FALLBACK: Currency = { code: "USD", symbol: "$", rate: 1, country: "" };

const RATES: Record<string, Currency> = {
  US: { code: "USD", symbol: "$", rate: 1, country: "United States" },
  GB: { code: "GBP", symbol: "£", rate: 0.79, country: "United Kingdom" },
  EU: { code: "EUR", symbol: "€", rate: 0.92, country: "Eurozone" },
  DE: { code: "EUR", symbol: "€", rate: 0.92, country: "Germany" },
  FR: { code: "EUR", symbol: "€", rate: 0.92, country: "France" },
  ES: { code: "EUR", symbol: "€", rate: 0.92, country: "Spain" },
  IT: { code: "EUR", symbol: "€", rate: 0.92, country: "Italy" },
  NL: { code: "EUR", symbol: "€", rate: 0.92, country: "Netherlands" },
  IE: { code: "EUR", symbol: "€", rate: 0.92, country: "Ireland" },
  IN: { code: "INR", symbol: "₹", rate: 84, country: "India" },
  CA: { code: "CAD", symbol: "C$", rate: 1.38, country: "Canada" },
  AU: { code: "AUD", symbol: "A$", rate: 1.52, country: "Australia" },
  NZ: { code: "NZD", symbol: "NZ$", rate: 1.65, country: "New Zealand" },
  JP: { code: "JPY", symbol: "¥", rate: 155, country: "Japan" },
  CN: { code: "CNY", symbol: "¥", rate: 7.2, country: "China" },
  SG: { code: "SGD", symbol: "S$", rate: 1.34, country: "Singapore" },
  HK: { code: "HKD", symbol: "HK$", rate: 7.8, country: "Hong Kong" },
  CH: { code: "CHF", symbol: "CHF ", rate: 0.88, country: "Switzerland" },
  SE: { code: "SEK", symbol: "kr ", rate: 10.5, country: "Sweden" },
  NO: { code: "NOK", symbol: "kr ", rate: 10.8, country: "Norway" },
  DK: { code: "DKK", symbol: "kr ", rate: 6.9, country: "Denmark" },
  BR: { code: "BRL", symbol: "R$", rate: 5.7, country: "Brazil" },
  MX: { code: "MXN", symbol: "MX$", rate: 20, country: "Mexico" },
  AR: { code: "ARS", symbol: "AR$", rate: 1000, country: "Argentina" },
  ZA: { code: "ZAR", symbol: "R", rate: 18.5, country: "South Africa" },
  AE: { code: "AED", symbol: "AED ", rate: 3.67, country: "UAE" },
  SA: { code: "SAR", symbol: "SAR ", rate: 3.75, country: "Saudi Arabia" },
  TR: { code: "TRY", symbol: "₺", rate: 34, country: "Turkey" },
  KR: { code: "KRW", symbol: "₩", rate: 1380, country: "South Korea" },
  ID: { code: "IDR", symbol: "Rp", rate: 15800, country: "Indonesia" },
  PH: { code: "PHP", symbol: "₱", rate: 58, country: "Philippines" },
  TH: { code: "THB", symbol: "฿", rate: 35, country: "Thailand" },
  MY: { code: "MYR", symbol: "RM", rate: 4.5, country: "Malaysia" },
  VN: { code: "VND", symbol: "₫", rate: 25000, country: "Vietnam" },
  PK: { code: "PKR", symbol: "Rs ", rate: 278, country: "Pakistan" },
  BD: { code: "BDT", symbol: "৳", rate: 119, country: "Bangladesh" },
  EG: { code: "EGP", symbol: "E£", rate: 49, country: "Egypt" },
  NG: { code: "NGN", symbol: "₦", rate: 1600, country: "Nigeria" },
  KE: { code: "KES", symbol: "KSh ", rate: 129, country: "Kenya" },
  IL: { code: "ILS", symbol: "₪", rate: 3.7, country: "Israel" },
  PL: { code: "PLN", symbol: "zł ", rate: 4, country: "Poland" },
  CZ: { code: "CZK", symbol: "Kč ", rate: 23, country: "Czechia" },
  RU: { code: "RUB", symbol: "₽", rate: 95, country: "Russia" },
};

function formatPrice(usd: number, c: Currency): string {
  if (usd === 0) return "Free";
  const v = usd * c.rate;
  let rounded: number;
  if (c.rate >= 100) rounded = Math.round(v / 10) * 10;
  else if (c.rate >= 10) rounded = Math.round(v);
  else rounded = Math.round(v * 100) / 100;
  const display = c.rate >= 10 ? rounded.toLocaleString() : rounded.toString();
  return `${c.symbol}${display}`;
}

function PricingPage() {
  const { from } = Route.useSearch();
  const isUpgrade = from === "app";
  const [currency, setCurrency] = useState<Currency>(FALLBACK);
  const [user, setUser] = useState<{ id: string; email: string | null } | null>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) setUser({ id: data.user.id, email: data.user.email ?? null });
    });
  }, []);

  useEffect(() => {
    let cancelled = false;
    let detected: Currency | null = null;

    async function detectCountry() {
      try {
        const res = await fetch("https://ipapi.co/json/");
        if (!res.ok) return null;
        const data = await res.json();
        const code = (data.country_code as string)?.toUpperCase();
        return code && RATES[code] ? RATES[code] : null;
      } catch {
        return null;
      }
    }

    async function refreshRate() {
      if (!detected) return;
      if (detected.code === "USD") {
        if (!cancelled) setCurrency(detected);
        return;
      }
      try {
        const res = await fetch("https://open.er-api.com/v6/latest/USD");
        if (!res.ok) throw new Error("fx");
        const fx = await res.json();
        const live = fx?.rates?.[detected.code];
        if (typeof live === "number" && live > 0) {
          if (!cancelled) setCurrency({ ...detected, rate: live });
          return;
        }
      } catch {
        // fall through
      }
      if (!cancelled) setCurrency(detected);
    }

    (async () => {
      detected = await detectCountry();
      if (detected) await refreshRate();
    })();

    // Re-verify FX every 60s while the page is open
    const timer = setInterval(refreshRate, 60_000);
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, []);

  const plans: Array<{
    key: "free" | "pro" | "max";
    name: string;
    usd: number;
    tagline: string;
    features: string[];
    accent: string;
    highlight: boolean;
  }> = [
    {
      key: "free",
      name: "Starter",
      usd: 0,
      tagline: "Try the boardroom",
      features: ["3 debates", "1 pitch deck", "1 revenue projection"],
      accent: "var(--gemini)",
      highlight: false,
    },
    {
      key: "pro",
      name: "Pro",
      usd: 8,
      tagline: "For builders shipping fast",
      features: ["10 debates", "3 pitch decks", "5 revenue projections"],
      accent: "var(--primary)",
      highlight: true,
    },
    {
      key: "max",
      name: "Scale",
      usd: 15,
      tagline: "For teams operating at speed",
      features: ["Unlimited debates", "5 pitch decks", "Unlimited revenue projections"],
      accent: "var(--claude)",
      highlight: false,
    },
  ];

  return (
    <div className="min-h-screen bg-background bg-neural relative overflow-hidden">
      <div aria-hidden className="pointer-events-none absolute -top-40 -left-40 w-[600px] h-[600px] rounded-full blur-3xl opacity-40"
        style={{ background: "radial-gradient(circle, var(--claude) 0%, transparent 70%)" }} />
      <div aria-hidden className="pointer-events-none absolute top-1/3 -right-40 w-[700px] h-[700px] rounded-full blur-3xl opacity-30"
        style={{ background: "radial-gradient(circle, var(--gemini) 0%, transparent 70%)" }} />
      <div aria-hidden className="pointer-events-none absolute -bottom-40 left-1/3 w-[500px] h-[500px] rounded-full blur-3xl opacity-25"
        style={{ background: "radial-gradient(circle, var(--primary) 0%, transparent 70%)" }} />

      <header className="relative z-10 flex items-center justify-between px-6 md:px-12 py-5">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, var(--claude), var(--gemini))" }}>
            <Brain className="w-5 h-5 text-background" />
          </div>
          <span className="font-bold text-lg tracking-tight">Suprbrain</span>
        </Link>
        <Link to="/login" className="px-4 py-2 text-sm font-semibold text-foreground hover:text-primary transition-colors">
          Sign in
        </Link>
      </header>

      <main className="relative z-10 px-6 md:px-12 pt-8 md:pt-16 pb-24 max-w-6xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-border bg-card/60 backdrop-blur text-xs font-semibold text-muted-foreground mb-6">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            Pricing
          </div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight leading-[1.05]">
            Pick the plan that fits{" "}
            <span style={{
              background: "linear-gradient(120deg, var(--claude), var(--primary), var(--gemini))",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}>your tempo</span>.
          </h1>
          <p className="mt-4 text-muted-foreground">
            Prices shown in {currency.code}
            {currency.country ? ` · ${currency.country}` : ""}.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {plans.map((p) => (
            <div
              key={p.name}
              className={`relative rounded-2xl border bg-card/70 backdrop-blur p-7 flex flex-col ${
                p.highlight ? "border-primary/60" : "border-border"
              }`}
              style={p.highlight ? { boxShadow: `0 0 0 1px ${p.accent}55, 0 20px 60px -20px ${p.accent}77` } : undefined}
            >
              {p.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-primary text-primary-foreground text-[10px] font-bold uppercase tracking-widest">
                  Most popular
                </div>
              )}
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ background: p.accent, boxShadow: `0 0 12px ${p.accent}` }} />
                <div className="font-bold text-lg">{p.name}</div>
              </div>
              <div className="text-xs text-muted-foreground mt-1">{p.tagline}</div>

              <div className="mt-5 flex items-baseline gap-1">
                <span className="text-4xl font-bold tracking-tight">{formatPrice(p.usd, currency)}</span>
                <span className="text-sm text-muted-foreground">/mo</span>
              </div>
              {p.usd > 0 && currency.code !== "USD" && (
                <div className="text-[11px] text-muted-foreground mt-1">≈ ${p.usd} USD</div>
              )}

              <ul className="mt-6 space-y-3 flex-1">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 mt-0.5 shrink-0" style={{ color: p.accent }} />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>

              {isUpgrade && p.usd > 0 ? (
                <a
                  href={buildUpgradeUrl(p.key as "pro" | "max", user?.id ?? null, user?.email ?? null)}
                  className={`mt-7 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-md font-semibold transition ${
                    p.highlight
                      ? "bg-primary text-primary-foreground hover:opacity-90 glow-primary"
                      : "border border-border bg-background/60 hover:bg-background"
                  }`}
                >
                  Upgrade <ArrowRight className="w-4 h-4" />
                </a>
              ) : (
                <Link
                  to={isUpgrade ? "/app" : "/login"}
                  className={`mt-7 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-md font-semibold transition ${
                    p.highlight
                      ? "bg-primary text-primary-foreground hover:opacity-90 glow-primary"
                      : "border border-border bg-background/60 hover:bg-background"
                  }`}
                >
                  {isUpgrade ? "Current plan" : "Get started"} <ArrowRight className="w-4 h-4" />
                </Link>
              )}
            </div>
          ))}
        </div>

        <p className="mt-10 text-center text-xs text-muted-foreground">
          Local prices are estimates converted from USD and may vary at checkout.
        </p>
      </main>
    </div>
  );
}
