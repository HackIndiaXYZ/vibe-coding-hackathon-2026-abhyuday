import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, Sparkles, Brain, Scale, FileText, Presentation } from "lucide-react";

export const Route = createFileRoute("/")({
  component: LandingPage,
});

type DemoTurn = { speaker: "Gemini" | "GPT-5" | "Claude" | "Verdict"; text: string };

const SAMPLE_DEBATES: { decision: string; turns: DemoTurn[] }[] = [
  {
    decision: "Should we raise a $5M seed now or bootstrap another 6 months?",
    turns: [
      { speaker: "Gemini", text: "Raise. Market window is open and competitors are circling — capital buys speed." },
      { speaker: "GPT-5", text: "Wait. Your CAC payback is still 14 months. Dilution at this valuation is expensive distraction." },
      { speaker: "Claude", text: "Raising masks unit economics issues. Fix retention first or you're funding a leaky bucket." },
      { speaker: "Verdict", text: "Bootstrap 3 more months, hit 110% NDR, then raise from a position of strength." },
    ],
  },
  {
    decision: "Move from product-led growth to an outbound sales motion?",
    turns: [
      { speaker: "Gemini", text: "Yes — your ICP is now mid-market. PLG won't reach VPs of Ops." },
      { speaker: "GPT-5", text: "Hybrid. Keep PLG funnel for SMB, layer 2 AEs for enterprise pilots." },
      { speaker: "Claude", text: "Don't abandon PLG signal. Outbound without product data is just spray and pray." },
      { speaker: "Verdict", text: "Hire 1 AE, target PLG-qualified accounts only. Measure for 90 days." },
    ],
  },
  {
    decision: "Pivot the consumer app into a B2B compliance tool?",
    turns: [
      { speaker: "Gemini", text: "The compliance angle has 10x the ACV and clear budget owners." },
      { speaker: "GPT-5", text: "Consumer brand equity dies the moment you pivot. Spin out a new entity." },
      { speaker: "Claude", text: "You have 12k DAUs. Killing that for an unvalidated B2B bet is reckless." },
      { speaker: "Verdict", text: "Run a 6-week B2B design partner sprint before touching the consumer app." },
    ],
  },
  {
    decision: "Ship the AI agent feature or polish the core workflow first?",
    turns: [
      { speaker: "Gemini", text: "Ship the agent. It's the demo that wins inbound and press." },
      { speaker: "GPT-5", text: "Polish first. Churn is 8% monthly — agents on a broken core just amplify the leak." },
      { speaker: "Claude", text: "Agents without reliable primitives erode trust. Fix the foundation." },
      { speaker: "Verdict", text: "Two weeks on core stability, then ship the agent as a flagship launch." },
    ],
  },
];

function LandingPage() {
  return (
    <div className="min-h-screen bg-background bg-neural relative overflow-hidden">
      {/* Glows */}
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 -left-40 w-[600px] h-[600px] rounded-full blur-3xl opacity-40"
        style={{ background: "radial-gradient(circle, var(--claude) 0%, transparent 70%)" }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute top-1/3 -right-40 w-[700px] h-[700px] rounded-full blur-3xl opacity-30"
        style={{ background: "radial-gradient(circle, var(--gemini) 0%, transparent 70%)" }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-40 left-1/3 w-[500px] h-[500px] rounded-full blur-3xl opacity-25"
        style={{ background: "radial-gradient(circle, var(--primary) 0%, transparent 70%)" }}
      />

      {/* Nav */}
      <header className="relative z-10 flex items-center justify-between px-6 md:px-12 py-5">
        <Link to="/" className="flex items-center gap-2">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, var(--claude), var(--gemini))" }}
          >
            <Brain className="w-5 h-5 text-background" />
          </div>
          <span className="font-bold text-lg tracking-tight">Suprbrain</span>
        </Link>
        <div className="flex items-center gap-2">
          <Link
            to="/login"
            className="px-4 py-2 text-sm font-semibold text-foreground hover:text-primary transition-colors"
          >
            Sign in
          </Link>
          <Link
            to="/pricing"
            className="px-4 py-2 text-sm font-semibold rounded-md bg-primary text-primary-foreground hover:opacity-90 transition glow-primary"
          >
            Get started
          </Link>

        </div>
      </header>

      {/* Hero */}
      <main className="relative z-10 px-6 md:px-12 pt-8 md:pt-16 pb-24 max-w-6xl mx-auto">
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-border bg-card/60 backdrop-blur text-xs font-semibold text-muted-foreground mb-6">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            Three AI minds. One decision.
          </div>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-[1.05]">
            Your startup's{" "}
            <span
              style={{
                background: "linear-gradient(120deg, var(--claude), var(--primary), var(--gemini))",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              boardroom
            </span>
            , powered by the top 3 AIs.
          </h1>
          <p className="mt-6 text-base md:text-lg text-muted-foreground leading-relaxed">
            Claude, Gemini, and ChatGPT argue your hardest decisions in real time — then deliver a verdict. Generate pitch decks and revenue projections from the same brain.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Link
              to="/login"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-md bg-primary text-primary-foreground font-semibold hover:opacity-90 transition glow-primary"
            >
              Start a debate <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/login"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-border bg-card/60 backdrop-blur font-semibold hover:bg-card transition"
            >
              Sign in
            </Link>
          </div>
        </div>

        {/* AI Trio */}
        <AITrio />

        {/* Debate preview */}
        <div className="mt-16">
          <DebatePreview />
        </div>

        {/* Features */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-4">
          <FeatureCard
            icon={<Scale className="w-5 h-5" />}
            title="Decision debates"
            text="Three models argue both sides, then a neutral judge synthesizes a verdict with confidence."
          />
          <FeatureCard
            icon={<Presentation className="w-5 h-5" />}
            title="Pitch decks"
            text="Generate investor-ready decks in four design templates — export to .pptx, .pdf, .docx."
          />
          <FeatureCard
            icon={<FileText className="w-5 h-5" />}
            title="Revenue projections"
            text="Stress-test growth scenarios with a clean chart and assumptions you can defend."
          />
        </div>

        <div className="mt-20 text-center">
          <Link
            to="/login"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-md bg-primary text-primary-foreground font-semibold hover:opacity-90 transition glow-primary"
          >
            Get your AI boardroom <ArrowRight className="w-4 h-4" />
          </Link>
          <p className="mt-3 text-xs text-muted-foreground">Free to start. No credit card.</p>
        </div>
      </main>
    </div>
  );
}


function AITrio() {
  const models = [
    { name: "Claude", color: "var(--claude)", trait: "The Skeptic", delay: "0s" },
    { name: "GPT-5", color: "var(--gpt)", trait: "The Strategist", delay: "0.4s" },
    { name: "Gemini", color: "var(--gemini)", trait: "The Optimist", delay: "0.8s" },
  ];
  return (
    <div className="mt-16 grid grid-cols-3 gap-3 md:gap-6 max-w-3xl mx-auto">
      {models.map((m) => (
        <div
          key={m.name}
          className="relative rounded-2xl border border-border bg-card/60 backdrop-blur p-4 md:p-6 text-center"
          style={{
            boxShadow: `0 0 0 1px ${m.color}33, 0 20px 60px -20px ${m.color}55`,
            animation: `floatY 4s ease-in-out infinite`,
            animationDelay: m.delay,
          }}
        >
          <div
            className="mx-auto w-12 h-12 md:w-16 md:h-16 rounded-full flex items-center justify-center mb-3"
            style={{
              background: `radial-gradient(circle, ${m.color}55 0%, transparent 70%)`,
            }}
          >
            <div
              className="w-3 h-3 md:w-4 md:h-4 rounded-full"
              style={{
                background: m.color,
                boxShadow: `0 0 20px ${m.color}, 0 0 40px ${m.color}88`,
                animation: "pulseGlow 2s ease-in-out infinite",
                animationDelay: m.delay,
              }}
            />
          </div>
          <div className="font-bold text-sm md:text-base" style={{ color: m.color }}>
            {m.name}
          </div>
          <div className="text-[10px] md:text-xs text-muted-foreground mt-1 font-semibold">
            {m.trait}
          </div>
        </div>
      ))}
      <style>{`
        @keyframes floatY {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-8px); }
        }
        @keyframes pulseGlow {
          0%, 100% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.3); opacity: 0.7; }
        }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(12px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeOut {
          to { opacity: 0; transform: translateY(-8px); }
        }
        @keyframes caretBlink {
          50% { opacity: 0; }
        }
      `}</style>
    </div>
  );
}

function DebatePreview() {
  const [debateIdx, setDebateIdx] = useState(0);
  const [turnIdx, setTurnIdx] = useState(0);
  const debate = SAMPLE_DEBATES[debateIdx];

  useEffect(() => {
    const t = setTimeout(() => {
      if (turnIdx < debate.turns.length) {
        setTurnIdx((i) => i + 1);
      } else {
        // pause then rotate to next debate
        const r = setTimeout(() => {
          setTurnIdx(0);
          setDebateIdx((i) => (i + 1) % SAMPLE_DEBATES.length);
        }, 2800);
        return () => clearTimeout(r);
      }
    }, turnIdx === 0 ? 600 : 1700);
    return () => clearTimeout(t);
  }, [turnIdx, debate.turns.length]);

  const speakerColor = (s: DemoTurn["speaker"]) => {
    if (s === "Gemini") return "var(--gemini)";
    if (s === "GPT-5") return "var(--gpt)";
    if (s === "Claude") return "var(--claude)";
    return "var(--primary)";
  };

  return (
    <div className="max-w-3xl mx-auto rounded-2xl border border-border bg-card/70 backdrop-blur p-5 md:p-7 glow-primary">
      <div className="flex items-center justify-between mb-4">
        <div className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">
          Live debate
        </div>
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-muted-foreground pulse-dot">
          <span style={{ color: "var(--claude)" }} />
          <span style={{ color: "var(--gpt)" }} />
          <span style={{ color: "var(--gemini)" }} />
          <span className="ml-2">thinking</span>
        </div>
      </div>

      {/* Decision input (read-only) */}
      <div className="rounded-lg border border-border bg-background/60 px-4 py-3 mb-5">
        <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-1">
          Decision
        </div>
        <div key={debateIdx} className="text-sm md:text-base font-semibold leading-snug" style={{ animation: "slideUp 0.5s ease-out" }}>
          {debate.decision}
          <span
            className="inline-block w-[2px] h-4 ml-1 align-middle bg-primary"
            style={{ animation: "caretBlink 1s infinite" }}
          />
        </div>
      </div>

      {/* Turns */}
      <div className="space-y-3 min-h-[260px]">
        {debate.turns.slice(0, turnIdx).map((t, i) => {
          const isVerdict = t.speaker === "Verdict";
          const color = speakerColor(t.speaker);
          return (
            <div
              key={`${debateIdx}-${i}`}
              className="rounded-lg p-3 md:p-4"
              style={{
                animation: "slideUp 0.45s ease-out",
                background: isVerdict ? `${color}15` : "transparent",
                border: isVerdict ? `1px solid ${color}55` : "1px solid var(--border)",
              }}
            >
              <div className="flex items-center gap-2 mb-1">
                <div
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ background: color, boxShadow: `0 0 8px ${color}` }}
                />
                <div className="text-[11px] font-bold uppercase tracking-wider" style={{ color }}>
                  {isVerdict ? "Final Verdict" : t.speaker}
                </div>
              </div>
              <div className="text-sm leading-relaxed text-foreground/90">{t.text}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function FeatureCard({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) {
  return (
    <div className="rounded-xl border border-border bg-card/60 backdrop-blur p-5 hover:border-primary/40 transition">
      <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center mb-3">
        {icon}
      </div>
      <div className="font-bold mb-1">{title}</div>
      <div className="text-sm text-muted-foreground leading-relaxed">{text}</div>
    </div>
  );
}
