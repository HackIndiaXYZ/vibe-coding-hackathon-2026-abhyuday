import { createFileRoute, Link } from "@tanstack/react-router";
import { Brain, ArrowRight, Check } from "lucide-react";

export const Route = createFileRoute("/guides/ai-pitch-deck-generator")({
  component: GuidePage,
  head: () => ({
    meta: [
      { title: "AI Pitch Deck Generator: How Founders Win Investors in 2026" },
      {
        name: "description",
        content:
          "How to use an AI pitch deck generator with multiple models (Claude, Gemini, GPT) to build investor-ready decks faster — without the single-model blind spots.",
      },
      { property: "og:title", content: "How to Use an AI Pitch Deck Generator to Win Over Investors" },
      {
        property: "og:description",
        content:
          "A founder's guide to multi-model AI pitch deck generation — critique, refine, and ship investor-ready slides.",
      },
      { property: "og:url", content: "https://suprbrain.lovable.app/guides/ai-pitch-deck-generator" },
      { property: "og:type", content: "article" },
    ],
    links: [
      { rel: "canonical", href: "https://suprbrain.lovable.app/guides/ai-pitch-deck-generator" },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Article",
          headline: "How to Use an AI Pitch Deck Generator to Win Over Investors",
          description:
            "A founder's guide to using multi-model AI (Claude, Gemini, GPT) to build investor-ready pitch decks.",
          author: { "@type": "Organization", name: "Suprbrain" },
          publisher: { "@type": "Organization", name: "Suprbrain" },
          mainEntityOfPage: "https://suprbrain.lovable.app/guides/ai-pitch-deck-generator",
        }),
      },
    ],
  }),
});

function GuidePage() {
  return (
    <div className="min-h-screen bg-background bg-neural">
      <header className="px-6 md:px-12 py-5 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, var(--claude), var(--gemini))" }}
          >
            <Brain className="w-5 h-5 text-background" />
          </div>
          <span className="font-bold text-lg tracking-tight">Suprbrain</span>
        </Link>
        <Link
          to="/pricing"
          className="px-4 py-2 text-sm font-semibold text-foreground hover:text-primary transition-colors"
        >
          Pricing
        </Link>
      </header>

      <main className="max-w-3xl mx-auto px-6 md:px-12 py-12 md:py-16">
        <article className="prose prose-invert max-w-none">
          <p className="text-xs uppercase tracking-widest text-muted-foreground mb-4">Founder guide</p>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight leading-[1.1] mb-6">
            How to Use an AI Pitch Deck Generator to Win Over Investors
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Most AI pitch deck generators are wrappers around a single language model. They produce
            slides that look polished but read like every other startup's deck — same structure, same
            buzzwords, same blind spots. Investors pattern-match on this in seconds. The fix isn't a
            better prompt; it's a different process.
          </p>

          <h2 className="text-2xl font-bold mt-12 mb-4">Why single-model AI decks fall flat</h2>
          <p className="text-muted-foreground leading-relaxed">
            One model means one perspective. Whatever it gets wrong — a weak market-size argument, a
            soft competitive moat, a vague go-to-market — sails through unchallenged. By the time an
            investor reads slide 5, they've already filed your deck under "another generic AI pitch."
          </p>

          <h2 className="text-2xl font-bold mt-12 mb-4">The AI boardroom approach</h2>
          <p className="text-muted-foreground leading-relaxed">
            Suprbrain runs three frontier models — Claude, Gemini, and GPT — against the same prompt
            and lets them critique each other. The output isn't a consensus blob; it's a synthesis
            after real disagreement. That's the difference between a deck that argues your case and a
            deck that lists facts about your company.
          </p>

          <ul className="space-y-3 mt-6">
            {[
              "Three independent critiques on the same slide before it ships",
              "Disagreements surface assumptions your team has stopped questioning",
              "Grounded in your company doc — not a generic template",
              "Exports to PPTX, PDF, and Google Slides-ready formats",
            ].map((point) => (
              <li key={point} className="flex items-start gap-3 text-foreground">
                <Check className="w-5 h-5 mt-0.5 shrink-0 text-primary" />
                <span>{point}</span>
              </li>
            ))}
          </ul>

          <h2 className="text-2xl font-bold mt-12 mb-4">The 4-step workflow</h2>
          <ol className="space-y-4 mt-4 text-muted-foreground leading-relaxed list-decimal pl-6">
            <li>
              <strong className="text-foreground">Add your company context.</strong> Upload a one-pager,
              brand brief, or product doc. Every slide is grounded in this — no hallucinated stats.
            </li>
            <li>
              <strong className="text-foreground">Pick a template.</strong> YC, Sequoia, or a custom
              narrative arc. Templates shape order, not content.
            </li>
            <li>
              <strong className="text-foreground">Run the boardroom.</strong> Three models draft and
              critique. You see the disagreement before the final slide.
            </li>
            <li>
              <strong className="text-foreground">Export and iterate.</strong> Ship to PPTX/PDF, then
              run a Decision Debate on the riskiest claim.
            </li>
          </ol>

          <h2 className="text-2xl font-bold mt-12 mb-4">What makes a deck actually investor-ready</h2>
          <p className="text-muted-foreground leading-relaxed">
            Investor-ready isn't about visual polish — Canva solved that years ago. It's about whether
            the deck survives a hostile read. The fastest way to test that is to have three
            adversarial readers go through it before you send it. That's literally what Suprbrain
            does, on every slide, automatically.
          </p>

          <div className="mt-12 rounded-2xl border border-border bg-card/60 p-8 text-center">
            <h3 className="text-xl font-bold mb-2">Try the AI boardroom on your next deck</h3>
            <p className="text-muted-foreground mb-6">
              Free to start — 1 pitch deck and 3 debates on the Starter plan.
            </p>
            <Link
              to="/login"
              className="inline-flex items-center gap-2 bg-primary text-primary-foreground rounded-full px-6 py-3 text-sm font-semibold glow-primary"
            >
              Start free <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </article>
      </main>
    </div>
  );
}
