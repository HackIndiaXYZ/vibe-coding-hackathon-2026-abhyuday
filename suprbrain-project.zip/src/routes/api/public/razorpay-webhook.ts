import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";
import { createHmac, timingSafeEqual } from "crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import type { Plan } from "@/lib/billing";

// Razorpay sends payment.captured / order.paid events.
// We attribute each payment to a Suprbrain user via notes.user_id (passed in
// the checkout URL) and map the plan via notes.plan, with a USD-amount
// fallback if the plan note is missing.
function planFromAmount(amountMinor: number, currency: string): Plan | null {
  // amountMinor is in the smallest unit of the given currency (paise for INR,
  // cents for USD). We only auto-classify USD here; for other currencies we
  // rely on notes.plan being set by the upgrade link.
  if (currency?.toUpperCase() === "USD") {
    const usd = amountMinor / 100;
    if (usd >= 14) return "max";
    if (usd >= 7) return "pro";
  }
  return null;
}

function monthBounds(now = new Date()) {
  const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const end = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));
  return { start, end };
}

export const Route = createFileRoute("/api/public/razorpay-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
        if (!secret) {
          console.error("[razorpay-webhook] missing RAZORPAY_WEBHOOK_SECRET");
          return new Response("Server misconfigured", { status: 500 });
        }

        const signature = request.headers.get("x-razorpay-signature");
        const body = await request.text();

        if (!signature) {
          return new Response("Missing signature", { status: 401 });
        }

        const expected = createHmac("sha256", secret).update(body).digest("hex");
        const sigBuf = Buffer.from(signature);
        const expBuf = Buffer.from(expected);
        if (sigBuf.length !== expBuf.length || !timingSafeEqual(sigBuf, expBuf)) {
          return new Response("Invalid signature", { status: 401 });
        }

        let event: {
          event?: string;
          payload?: {
            payment?: { entity?: {
              id?: string;
              amount?: number;
              currency?: string;
              status?: string;
              notes?: Record<string, string>;
              email?: string;
            }};
          };
        };
        try {
          event = JSON.parse(body);
        } catch {
          return new Response("Invalid JSON", { status: 400 });
        }

        // We only act on successful payment events.
        const eventName = event.event ?? "";
        if (!["payment.captured", "order.paid"].includes(eventName)) {
          return new Response("ok", { status: 200 });
        }

        const payment = event.payload?.payment?.entity;
        if (!payment) return new Response("ok", { status: 200 });

        const notes = payment.notes ?? {};
        const userId = notes.user_id;
        if (!userId) {
          console.warn("[razorpay-webhook] payment missing notes.user_id", payment.id);
          return new Response("ok (no user_id)", { status: 200 });
        }

        const notePlan = (notes.plan ?? "").toLowerCase();
        const plan: Plan =
          notePlan === "pro" || notePlan === "max"
            ? (notePlan as Plan)
            : planFromAmount(payment.amount ?? 0, payment.currency ?? "USD") ?? "pro";

        const { start, end } = monthBounds();

        // Upsert subscription
        const { error: subErr } = await supabaseAdmin
          .from("subscriptions")
          .upsert(
            {
              user_id: userId,
              plan,
              current_period_start: start.toISOString(),
              current_period_end: end.toISOString(),
              updated_at: new Date().toISOString(),
            },
            { onConflict: "user_id" },
          );
        if (subErr) {
          console.error("[razorpay-webhook] subscription upsert failed", subErr);
          return new Response("DB error", { status: 500 });
        }

        // Record transaction (best-effort; idempotent on provider_ref)
        const amountUsd =
          (payment.currency ?? "").toUpperCase() === "USD"
            ? (payment.amount ?? 0) / 100
            : plan === "max"
              ? 15
              : 8;

        await supabaseAdmin.from("transactions").insert({
          user_id: userId,
          plan,
          amount_usd: amountUsd,
          currency: (payment.currency ?? "USD").toUpperCase(),
          status: "succeeded",
          provider: "razorpay",
          provider_ref: payment.id ?? null,
        });

        return new Response("ok", { status: 200 });
      },
    },
  },
});
