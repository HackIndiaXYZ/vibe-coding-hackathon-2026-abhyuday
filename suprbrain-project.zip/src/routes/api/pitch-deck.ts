import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";
import { generateText } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway";

const SlideSchema = z.object({
  title: z.string(),
  subtitle: z.string().optional(),
  bullets: z.array(z.string()).min(4).max(8),
});

const DeckSchema = z.object({
  company: z.string(),
  tagline: z.string(),
  slides: z.array(SlideSchema).min(8).max(12),
});

function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const raw = fenced ? fenced[1] : text;
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("Model did not return JSON");
  return JSON.parse(raw.slice(start, end + 1));
}

export const Route = createFileRoute("/api/pitch-deck")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        const { requireUser, consumeOrReject } = await import("@/lib/api-auth.server");
        const auth = await requireUser(request);
        if (!auth.ok) return auth.response;

        const { brand, templateId } = (await request.json()) as {
          brand?: string;
          templateId?: string;
        };
        if (!brand || brand.trim().length < 20) {
          return new Response("Provide a brand identity document.", { status: 400 });
        }

        const quota = await consumeOrReject(auth.userId, "deck");
        if (!quota.ok) return quota.response;

        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const gateway = createLovableAiGatewayProvider(key);

        try {
          const { text } = await generateText({
            model: gateway("google/gemini-3-flash-preview"),
            system:
              "You are a world-class startup pitch coach. Always respond with professional, constructive, respectful language. Generate a 10-slide investor pitch deck from the brand identity. Slides should follow the YC arc: 1) Title, 2) Problem, 3) Solution, 4) Why Now, 5) Market Size, 6) Product, 7) Traction, 8) Business Model, 9) Team, 10) Ask. Each slide MUST have between 5 and 7 substantive bullets. Bullets should be concrete, specific, and information-dense — include numbers, named customers, frameworks, mechanisms, or specific differentiators where possible. Avoid one-liners and filler. Infer details intelligently from the brand document. Respond ONLY with valid JSON matching this TypeScript type, no prose, no markdown fences: { company: string; tagline: string; slides: Array<{ title: string; subtitle?: string; bullets: string[] }> }. Provide exactly 10 slides.",
            prompt: `BRAND IDENTITY DOCUMENT:\n${brand}\n\nReturn the JSON now.`,
          });

          const parsed = DeckSchema.parse(extractJson(text));
          return Response.json({ ...parsed, templateId: templateId ?? "midnight" });

        } catch (e) {
          console.error("[pitch-deck]", e);
          return new Response("AI generation temporarily unavailable. Please try again.", { status: 502 });
        }
      },
    },
  },
});
