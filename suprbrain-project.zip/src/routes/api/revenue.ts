import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";
import { generateText } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway";

const YearSchema = z.object({
  year: z.number().int(),
  revenue: z.number(),
  low: z.number(),
  high: z.number(),
});

const ProjectionSchema = z.object({
  company: z.string(),
  currency: z.string().default("USD"),
  baseYear: z.number().int(),
  summary: z.string(),
  assumptions: z.array(z.string()).min(2).max(8),
  drivers: z.array(z.string()).min(2).max(6),
  risks: z.array(z.string()).min(2).max(6),
  yearly: z.array(YearSchema).min(3).max(11),
});

type Forecaster = {
  name: "Gemini" | "ChatGPT" | "Claude";
  model: string;
  stance: string;
};

const FORECASTERS: Forecaster[] = [
  {
    name: "Gemini",
    model: "google/gemini-3-flash-preview",
    stance:
      "market-expansion analyst: weigh demand, timing, and upside, but only when the data supports it",
  },
  {
    name: "ChatGPT",
    model: "openai/gpt-5",
    stance:
      "FP&A strategist: prioritize unit economics, historical run-rate, seasonality, and defensible base cases",
  },
  {
    name: "Claude",
    model: "openai/gpt-5.4",
    stance:
      "risk-focused analyst: stress-test declines, churn, concentration, and cases where revenue stays flat or falls",
  },
];

function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const raw = fenced ? fenced[1] : text;
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("Model did not return JSON");
  return JSON.parse(raw.slice(start, end + 1));
}

type Forecast = z.infer<typeof ProjectionSchema> & { model: Forecaster["name"] };

function cleanPoint(point: z.infer<typeof YearSchema>) {
  const revenue = Math.round(Number(point.revenue) || 0);
  const rawLow = Math.round(Number(point.low) || revenue);
  const rawHigh = Math.round(Number(point.high) || revenue);
  return {
    year: point.year,
    revenue,
    low: Math.min(rawLow, rawHigh, revenue),
    high: Math.max(rawLow, rawHigh, revenue),
  };
}

function interpolate(series: z.infer<typeof YearSchema>[], year: number) {
  const sorted = series.map(cleanPoint).sort((a, b) => a.year - b.year);
  const exact = sorted.find((p) => p.year === year);
  if (exact) return exact;
  const before = [...sorted].reverse().find((p) => p.year < year);
  const after = sorted.find((p) => p.year > year);
  if (!before) return sorted[0];
  if (!after) return sorted[sorted.length - 1];
  const span = after.year - before.year || 1;
  const t = (year - before.year) / span;
  return cleanPoint({
    year,
    revenue: before.revenue + (after.revenue - before.revenue) * t,
    low: before.low + (after.low - before.low) * t,
    high: before.high + (after.high - before.high) * t,
  });
}

function chooseBaseYear(forecasts: Forecast[]) {
  const counts = new Map<number, number>();
  forecasts.forEach((f) => counts.set(f.baseYear, (counts.get(f.baseYear) ?? 0) + 1));
  return (
    [...counts.entries()].sort((a, b) => b[1] - a[1] || b[0] - a[0])[0]?.[0] ??
    forecasts[0].baseYear
  );
}

function averagePoints(points: ReturnType<typeof cleanPoint>[], year: number) {
  const avg = (key: "revenue" | "low" | "high") =>
    Math.round(points.reduce((sum, p) => sum + p[key], 0) / Math.max(1, points.length));
  return cleanPoint({ year, revenue: avg("revenue"), low: avg("low"), high: avg("high") });
}

function firstUnique(items: string[], max: number) {
  return [...new Set(items.map((item) => item.trim()).filter(Boolean))].slice(0, max);
}

export const Route = createFileRoute("/api/revenue")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        const { requireUser, consumeOrReject } = await import("@/lib/api-auth.server");
        const auth = await requireUser(request);
        if (!auth.ok) return auth.response;

        const { history, horizon, companyName } = (await request.json()) as {
          history?: string;
          horizon?: number;
          companyName?: string;
        };
        if (!history || history.trim().length < 20) {
          return new Response("Provide a financial history document.", { status: 400 });
        }
        const years = Math.max(3, Math.min(10, Number(horizon) || 5));

        const quota = await consumeOrReject(auth.userId, "revenue");
        if (!quota.ok) return quota.response;

        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const gateway = createLovableAiGatewayProvider(key);

        try {
          const forecasts = await Promise.all(
            FORECASTERS.map(async (forecaster) => {
              const { text } = await generateText({
                model: gateway(forecaster.model),
                system:
                  `You are ${forecaster.name}, a ${forecaster.stance}. Read the actual company financial history before forecasting. ` +
                  "Do NOT default to appreciation. If the historical data is declining, volatile, flat, weak, or missing growth evidence, your projection may decline or stay flat. " +
                  "Preserve the most recent full year as the baseYear actual. Project from the supplied numbers, named metrics, customer counts, churn, ARPU, bookings, or segments. " +
                  "Return exactly " +
                  (years + 1) +
                  " yearly entries: the baseYear actual followed by " +
                  years +
                  " projected years. Always include low/high bands that bracket revenue. Use whole-number revenue values in the document's primary currency. " +
                  "Keep assumptions, drivers, and risks concrete and data-referenced. Respond ONLY with valid JSON, no prose, no markdown fences, matching: { company: string; currency: string; baseYear: number; summary: string; assumptions: string[] (2-8 items); drivers: string[] (2-6 items); risks: string[] (2-6 items); yearly: Array<{ year: number; revenue: number; low: number; high: number }> }.",
                prompt: `COMPANY: ${companyName || "(unspecified)"}\nFORECASTER: ${forecaster.name}\nPROJECTION HORIZON: ${years} years\n\nFINANCIAL HISTORY DOCUMENT:\n${history}\n\nReturn the JSON now.`,
              });

              return { ...ProjectionSchema.parse(extractJson(text)), model: forecaster.name };
            }),
          );

          const baseYear = chooseBaseYear(forecasts);
          const yearly = Array.from({ length: years + 1 }, (_, i) => baseYear + i).map((year) =>
            averagePoints(
              forecasts.map((forecast) => interpolate(forecast.yearly, year)),
              year,
            ),
          );
          const company = companyName?.trim() || forecasts[0].company;
          const currency = forecasts.find((f) => f.currency)?.currency ?? "USD";

          return Response.json({
            company,
            currency,
            baseYear,
            summary: `Average of Gemini, ChatGPT, and Claude: ${forecasts.map((f) => `${f.model}: ${f.summary}`).join(" ")}`,
            assumptions: firstUnique(
              forecasts.flatMap((f) => f.assumptions),
              8,
            ),
            drivers: firstUnique(
              forecasts.flatMap((f) => f.drivers),
              6,
            ),
            risks: firstUnique(
              forecasts.flatMap((f) => f.risks),
              6,
            ),
            yearly,
            modelProjections: forecasts.map((forecast) => ({
              ...forecast,
              yearly: Array.from({ length: years + 1 }, (_, i) => baseYear + i).map((year) =>
                interpolate(forecast.yearly, year),
              ),
            })),
          });
        } catch (e) {
          console.error("[revenue]", e);
          return new Response("AI generation temporarily unavailable. Please try again.", { status: 502 });
        }
      },
    },
  },
});
