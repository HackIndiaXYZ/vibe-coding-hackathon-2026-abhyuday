import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";
import { generateText } from "ai";
import { createLovableAiGatewayProvider, PERSONAS } from "@/lib/ai-gateway";

type Body = { decision?: string; context?: string };

type Turn = { speaker: string; text: string };

const SAFETY_RULES =
  "Always respond with professional, constructive, and respectful language. Do not include hate speech, harassment, sexually explicit content, violence, self-harm, illegal activity, disinformation, or personal data. Keep the tone analytical and startup-focused.";

export const Route = createFileRoute("/api/debate")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        const { requireUser, consumeOrReject } = await import("@/lib/api-auth.server");
        const auth = await requireUser(request);
        if (!auth.ok) return auth.response;

        const { decision, context } = (await request.json()) as Body;
        if (!decision || decision.trim().length < 4) {
          return new Response("Provide a decision to debate.", { status: 400 });
        }

        const quota = await consumeOrReject(auth.userId, "debate");
        if (!quota.ok) return quota.response;

        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const gateway = createLovableAiGatewayProvider(key);

        const decisionBlock = `STARTUP DECISION UNDER REVIEW:\n${decision}\n\nADDITIONAL CONTEXT:\n${
          context?.trim() || "(none provided)"
        }`;

        const round1: Turn[] = [];

        // Round 1 — each persona gives an opening take in parallel
        const openings = await Promise.all(
          PERSONAS.map(async (p) => {
            const { text } = await generateText({
              model: gateway(p.model),
              system: `${p.systemTrait}\n${SAFETY_RULES}\nYou are debating two other AI advisors. Keep your opening take under 110 words. No preamble, no headings — speak directly.`,
              prompt: `${decisionBlock}\n\nGive your opening verdict and the single strongest reason behind it.`,
            });
            return { speaker: p.name, text: text.trim() };
          })
        );
        round1.push(...openings);

        const transcript1 = round1
          .map((t) => `${t.speaker}: ${t.text}`)
          .join("\n\n");

        // Round 2 — each persona rebuts the others
        const rebuttals = await Promise.all(
          PERSONAS.map(async (p) => {
            const others = round1
              .filter((t) => t.speaker !== p.name)
              .map((t) => `${t.speaker}: ${t.text}`)
              .join("\n\n");
            const { text } = await generateText({
              model: gateway(p.model),
              system: `${p.systemTrait}\n${SAFETY_RULES}\nYou are in round 2 of a debate. Push back specifically on the other advisors' weakest point. Under 100 words. No headings.`,
              prompt: `${decisionBlock}\n\nOTHER ADVISORS SAID:\n${others}\n\nYOUR REBUTTAL:`,
            });
            return { speaker: p.name, text: text.trim() };
          })
        );

        const fullTranscript = `ROUND 1\n${transcript1}\n\nROUND 2\n${rebuttals
          .map((t) => `${t.speaker}: ${t.text}`)
          .join("\n\n")}`;

        // Final synthesis — neutral judge
        const { text: verdict } = await generateText({
          model: gateway("google/gemini-3-flash-preview"),
          system:
            `${SAFETY_RULES}\nYou are a neutral judge synthesizing a debate between three AI advisors. Be decisive. Return EXACTLY this format:\n\nRECOMMENDATION: <one line>\nCONFIDENCE: <Low|Medium|High>\nKEY REASONING: <2-3 tight sentences>\nWATCH OUT FOR: <one specific risk to monitor>`,
          prompt: `${decisionBlock}\n\nFULL DEBATE TRANSCRIPT:\n${fullTranscript}\n\nDeliver the final verdict.`,
        });

        return Response.json({
          round1,
          round2: rebuttals,
          verdict: verdict.trim(),
        });
      },
    },
  },
});
