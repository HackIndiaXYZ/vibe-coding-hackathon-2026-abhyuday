import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Sparkles, ArrowRight, LogOut, Plus, Building2, Trash2, History, FileText, FileType, Presentation, Sparkle } from "lucide-react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { parseFileToText } from "@/lib/parse-file";
import type { Deck, Slide, TemplateId, DeckTemplate } from "@/lib/deck-types";
import { TEMPLATES, getTemplate } from "@/lib/deck-types";
import { downloadDeckPptx, downloadDeckDocx, downloadDeckPdf } from "@/lib/deck-export";
import { RevenuePanel } from "@/components/RevenuePanel";
import { getBillingStatus } from "@/lib/billing.functions";
import { PLAN_LABEL, PLAN_LIMITS, FEATURE_LABEL, type Plan, type Feature } from "@/lib/billing";

type BillingStatus = {
  plan: Plan;
  currentPeriodEnd: string;
  limits: Record<Feature, number | null>;
  usage: Record<Feature, number>;
};

export function formatLimitMessage(
  feature: Feature,
  plan: Plan,
  limit: number,
  resetAt: string,
) {
  const resetDate = new Date(resetAt).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
  return `Your ${PLAN_LABEL[plan]} plan limit of ${limit} ${FEATURE_LABEL[feature]} this month has been reached. Limits reset on ${resetDate} — or upgrade for more.`;
}

export const Route = createFileRoute("/app")({
  component: SuperBrain,
  head: () => ({
    meta: [
      { title: "Your AI Boardroom — Suprbrain" },
      { name: "description", content: "Run multi-model AI debates, generate pitch decks, and project revenue for your startup inside your Suprbrain dashboard." },
      { property: "og:title", content: "Your AI Boardroom — Suprbrain" },
      { property: "og:description", content: "Run multi-model AI debates, generate pitch decks, and project revenue inside your Suprbrain dashboard." },
      { property: "og:url", content: "https://suprbrain.lovable.app/app" },
      { name: "robots", content: "noindex" },
    ],
  }),
});

type Turn = { speaker: string; text: string };
type DebateResult = { round1: Turn[]; round2: Turn[]; verdict: string };
type Company = {
  id: string;
  name: string;
  document_text: string | null;
  document_filename: string | null;
};
type DebateRow = {
  id: string;
  decision: string;
  context: string | null;
  result: DebateResult;
  created_at: string;
};

const SPEAKER_COLOR: Record<string, string> = {
  Gemini: "var(--gemini)",
  "GPT-5": "var(--gpt)",
  Claude: "var(--claude)",
};

type Tab = "debate" | "deck" | "revenue" | "company";

function SuperBrain() {
  const [tab, setTab] = useState<Tab>("debate");
  const [session, setSession] = useState<Session | null>(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [selectedCompanyId, setSelectedCompanyId] = useState<string | null>(null);
  const [billing, setBilling] = useState<BillingStatus | null>(null);
  const navigate = useNavigate();
  const fetchBilling = useServerFn(getBillingStatus);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
      setAuthChecked(true);
      if (!s) navigate({ to: "/login" });
    });
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setAuthChecked(true);
      if (!data.session) navigate({ to: "/login" });
    });
    return () => sub.subscription.unsubscribe();
  }, [navigate]);

  const refreshCompanies = useCallback(async () => {
    const { data } = await supabase
      .from("companies")
      .select("id, name, document_text, document_filename")
      .order("created_at", { ascending: false });
    if (data) {
      setCompanies(data);
      setSelectedCompanyId((prev) => prev ?? data[0]?.id ?? null);
    }
  }, []);

  const refreshBilling = useCallback(async () => {
    try {
      const b = (await fetchBilling()) as BillingStatus;
      setBilling(b);
    } catch (e) {
      console.error("billing", e);
    }
  }, [fetchBilling]);

  useEffect(() => {
    if (session) {
      refreshCompanies();
      refreshBilling();
    }
  }, [session, refreshCompanies, refreshBilling]);

  const selectedCompany = companies.find((c) => c.id === selectedCompanyId) ?? null;

  if (!authChecked || !session) {
    return (
      <div className="min-h-screen bg-neural flex items-center justify-center">
        <Loader2 className="size-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neural">
      <header className="border-b border-border/50 backdrop-blur-sm sticky top-0 z-10 bg-background/70">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between gap-4 flex-wrap">
          <div className="leading-tight">
            <div className="text-lg">Suprbrain</div>
            <div className="text-[11px] text-muted-foreground uppercase tracking-widest">
              Three minds. One decision.
            </div>
          </div>
          <nav className="flex gap-1 p-1 rounded-full bg-secondary text-sm">
            {(["debate", "deck", "revenue", "company"] as Tab[]).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`px-4 py-1.5 rounded-full transition ${
                  tab === t ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                }`}
              >
                {t === "debate"
                  ? "Decision Debate"
                  : t === "deck"
                    ? "Pitch Deck"
                    : t === "revenue"
                      ? "Revenue Projection"
                      : "Company"}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            {companies.length > 0 && (
              <select
                value={selectedCompanyId ?? ""}
                onChange={(e) => setSelectedCompanyId(e.target.value || null)}
                className="text-xs rounded-full border border-border bg-background px-3 py-1.5 outline-none focus:border-primary"
                title="Active company"
              >
                {companies.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            )}
            <span className="hidden sm:block text-xs text-muted-foreground truncate max-w-[140px]">
              {session.user.email}
            </span>
            <span
              className={`hidden md:inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest border ${
                billing?.plan === "max"
                  ? "border-[color:var(--claude)] text-[color:var(--claude)]"
                  : billing?.plan === "pro"
                    ? "border-primary text-primary"
                    : "border-border text-muted-foreground"
              }`}
              title="Your current subscription"
            >
              {billing ? PLAN_LABEL[billing.plan] : "Free"} plan
            </span>
            <Link
              to="/pricing"
              search={{ from: "app" }}
              className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold bg-primary text-primary-foreground hover:opacity-90 transition glow-primary"
              title="Upgrade your plan"
            >
              <Sparkle className="size-3.5" />
              <span>Upgrade</span>
              <span className="opacity-70 border-l border-primary-foreground/30 pl-1.5 ml-0.5">
                {billing ? PLAN_LABEL[billing.plan] : "Free"}
              </span>
            </Link>
            <button
              onClick={() => supabase.auth.signOut()}
              className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5 text-xs hover:border-primary transition"
              title="Sign out"
            >
              <LogOut className="size-3.5" /> Sign out
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-10">
        <h1 className="sr-only">Your AI Boardroom</h1>
        {billing && (
          <div className="mb-6 flex items-center justify-between gap-3 rounded-2xl border border-border bg-card/60 px-4 py-3 text-xs flex-wrap">
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
              <span className="uppercase tracking-widest text-muted-foreground">
                {PLAN_LABEL[billing.plan]} plan · usage this month
              </span>
              {(["debate", "deck", "revenue"] as Feature[]).map((f) => {
                const lim = PLAN_LIMITS[billing.plan][f];
                const used = billing.usage[f];
                return (
                  <span key={f} className="text-foreground/80">
                    {FEATURE_LABEL[f]}:{" "}
                    <span className="font-semibold">
                      {used}/{lim === null ? "∞" : lim}
                    </span>
                  </span>
                );
              })}
            </div>
            <span className="text-muted-foreground">
              Resets{" "}
              {new Date(billing.currentPeriodEnd).toLocaleDateString(undefined, {
                month: "short",
                day: "numeric",
              })}
            </span>
          </div>
        )}
        <div hidden={tab !== "debate"}>
          <DebatePanel
            company={selectedCompany}
            onAskAddCompany={() => setTab("company")}
            onConsumed={refreshBilling}
          />
        </div>
        <div hidden={tab !== "deck"}>
          <DeckPanel company={selectedCompany} onConsumed={refreshBilling} />
        </div>
        <div hidden={tab !== "revenue"}>
          <RevenuePanel company={selectedCompany} onConsumed={refreshBilling} />
        </div>
        <div hidden={tab !== "company"}>
          <CompanyPanel
            companies={companies}
            selectedId={selectedCompanyId}
            onSelect={setSelectedCompanyId}
            onChanged={refreshCompanies}
          />
        </div>
      </main>

      <footer className="border-t border-border/50 mt-10">
        <div className="max-w-6xl mx-auto px-6 py-6 text-xs text-muted-foreground text-center">
          © Suprbrain 2026
        </div>
      </footer>
    </div>
  );
}

/* ============================== COMPANY ============================== */

function CompanyPanel({
  companies,
  selectedId,
  onSelect,
  onChanged,
}: {
  companies: Company[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onChanged: () => Promise<void> | void;
}) {
  const [name, setName] = useState("");
  const [docText, setDocText] = useState("");
  const [docName, setDocName] = useState<string | null>(null);
  const [parsing, setParsing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [recentDebates, setRecentDebates] = useState<DebateRow[]>([]);

  const loadRecentDebates = useCallback(async () => {
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return;
    const { data } = await supabase
      .from("debates")
      .select("id, decision, context, result, created_at")
      .eq("user_id", u.user.id)
      .order("created_at", { ascending: false })
      .limit(5);
    if (data) setRecentDebates(data as unknown as DebateRow[]);
  }, []);

  useEffect(() => {
    loadRecentDebates();
  }, [loadRecentDebates]);

  const onFile = async (file: File) => {
    setError(null);
    setParsing(true);
    try {
      const text = await parseFileToText(file);
      if (text.length < 20) throw new Error("Couldn't extract enough text from that file.");
      setDocText(text);
      setDocName(file.name);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn't read that file.");
    } finally {
      setParsing(false);
    }
  };

  const save = async () => {
    setError(null);
    setSaving(true);
    try {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Not signed in");
      const { data, error } = await supabase
        .from("companies")
        .insert({
          user_id: u.user.id,
          name: name.trim(),
          document_text: docText || null,
          document_filename: docName,
        })
        .select("id")
        .single();
      if (error) throw error;
      setName("");
      setDocText("");
      setDocName(null);
      await onChanged();
      if (data?.id) onSelect(data.id);
      await loadRecentDebates();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn't save company.");
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id: string) => {
    await supabase.from("companies").delete().eq("id", id);
    await onChanged();
  };

  return (
    <div className="grid lg:grid-cols-[1.1fr_1fr] gap-8">
      <section className="space-y-5">
        <div>
          <h1 className="text-4xl leading-tight">
            Add a <span className="text-primary">company.</span>
          </h1>
          <p className="text-muted-foreground mt-3 text-sm font-medium">
            Give the three AIs a shared reference so every debate and deck is grounded in your
            company's context.
          </p>
        </div>

        <label className="block">
          <span className="text-xs uppercase tracking-widest text-muted-foreground">
            Company name <span className="text-destructive">*</span>
          </span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Acme Inc."
            maxLength={120}
            className="mt-2 w-full rounded-xl bg-card border border-border p-3 text-sm font-medium outline-none focus:border-primary transition"
          />
        </label>

        <div>
          <span className="text-xs uppercase tracking-widest text-muted-foreground">
            Reference document (optional)
          </span>
          <div className="mt-2">
            <label className="inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-xs cursor-pointer hover:border-primary transition">
              {parsing ? (
                <>
                  <Loader2 className="size-3.5 animate-spin" /> Reading file…
                </>
              ) : (
                <>Upload .pdf, .docx, .txt or .md</>
              )}
              <input
                type="file"
                accept=".pdf,.docx,.doc,.txt,.md,.markdown"
                className="hidden"
                disabled={parsing}
                onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])}
              />
            </label>
            {docName && !parsing && (
              <div className="mt-2 text-[11px] text-muted-foreground">
                {docName} — {docText.length.toLocaleString()} characters loaded.
              </div>
            )}
          </div>
        </div>

        <button
          onClick={save}
          disabled={saving || name.trim().length < 1}
          className="inline-flex items-center gap-2 bg-primary text-primary-foreground rounded-full px-6 py-3 text-sm disabled:opacity-50 disabled:cursor-not-allowed glow-primary"
        >
          {saving ? (
            <>
              <Loader2 className="size-4 animate-spin" /> Saving…
            </>
          ) : (
            <>
              <Plus className="size-4" /> Add company
            </>
          )}
        </button>

        {error && <div className="text-destructive text-sm">{error}</div>}
      </section>

      <section className="space-y-6">
        <div>
          <div className="text-xs uppercase tracking-widest text-muted-foreground mb-3">
            Your companies
          </div>
          {companies.length === 0 ? (
            <div className="border border-dashed border-border rounded-2xl p-8 text-center text-sm text-muted-foreground">
              <Building2 className="size-6 mx-auto mb-3 opacity-60" />
              No companies yet.
            </div>
          ) : (
            <ul className="space-y-2">
              {companies.map((c) => (
                <li
                  key={c.id}
                  className={`rounded-2xl border p-4 flex items-center justify-between gap-3 transition ${
                    c.id === selectedId ? "border-primary bg-primary/5" : "border-border bg-card"
                  }`}
                >
                  <button
                    onClick={() => onSelect(c.id)}
                    className="text-left flex-1 min-w-0"
                  >
                    <div className="text-sm font-medium truncate">{c.name}</div>
                    <div className="text-[11px] text-muted-foreground truncate">
                      {c.document_filename
                        ? `📄 ${c.document_filename}`
                        : "No reference document"}
                    </div>
                  </button>
                  <button
                    onClick={() => remove(c.id)}
                    className="text-muted-foreground hover:text-destructive transition"
                    title="Delete company"
                    aria-label="Delete company"
                  >
                    <Trash2 className="size-4" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div>
          <div className="text-xs uppercase tracking-widest text-muted-foreground mb-3 flex items-center gap-2">
            <History className="size-3.5" /> Recent debates
          </div>
          {recentDebates.length === 0 ? (
            <div className="border border-dashed border-border rounded-2xl p-6 text-center text-sm text-muted-foreground">
              No debates yet.
            </div>
          ) : (
            <ul className="space-y-2">
              {recentDebates.map((d) => (
                <li
                  key={d.id}
                  className="rounded-2xl border border-border bg-card p-4 transition hover:border-primary/50"
                >
                  <div className="text-sm font-medium line-clamp-2">{d.decision}</div>
                  <div className="text-[11px] text-muted-foreground mt-1 flex items-center gap-2">
                    <span>
                      {new Date(d.created_at).toLocaleDateString(undefined, {
                        month: "short",
                        day: "numeric",
                      })}
                    </span>
                    {d.result?.verdict && (
                      <span className="inline-flex items-center gap-1 text-primary/80">
                        · Verdict: {d.result.verdict.slice(1, 120).split("\n")[1] || d.result.verdict.slice(0, 120).split("\n")[0]}
                      </span>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </div>
  );
}

/* ============================== DEBATE ============================== */

function DebatePanel({
  company,
  onAskAddCompany,
  onConsumed,
}: {
  company: Company | null;
  onAskAddCompany: () => void;
  onConsumed: () => Promise<void> | void;
}) {
  const [decision, setDecision] = useState("");
  const [context, setContext] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<DebateResult | null>(null);
  const [history, setHistory] = useState<DebateRow[]>([]);

  const loadHistory = useCallback(async () => {
    if (!company) {
      setHistory([]);
      return;
    }
    const { data } = await supabase
      .from("debates")
      .select("id, decision, context, result, created_at")
      .eq("company_id", company.id)
      .order("created_at", { ascending: false })
      .limit(10);
    if (data) setHistory(data as unknown as DebateRow[]);
  }, [company]);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  const run = async () => {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const mergedContext = [
        company?.document_text
          ? `COMPANY REFERENCE DOC (${company.name} — use this as the source of truth for company-specific facts):\n${company.document_text}`
          : company
            ? `COMPANY: ${company.name}`
            : "",
        context.trim() ? `USER CONTEXT:\n${context.trim()}` : "",
      ]
        .filter(Boolean)
        .join("\n\n---\n\n");

      const { authedFetch, handleQuotaResponse } = await import("@/lib/api-client");
      const res = await authedFetch("/api/debate", {
        method: "POST",
        body: JSON.stringify({ decision, context: mergedContext }),
      });
      const quotaMsg = await handleQuotaResponse(res, "debate");
      if (quotaMsg) throw new Error(quotaMsg);
      if (!res.ok) throw new Error(await res.text());
      await onConsumed();
      const r = (await res.json()) as DebateResult;
      setResult(r);

      if (company) {
        const { data: u } = await supabase.auth.getUser();
        if (u.user) {
          await supabase.from("debates").insert({
            user_id: u.user.id,
            company_id: company.id,
            decision,
            context: context || null,
            result: r as never,
          });
          await loadHistory();
        }
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-10">
      <div className="grid lg:grid-cols-[1fr_1.3fr] gap-8">
        <section className="space-y-5">
          <div>
            <h1 className="text-4xl leading-tight">
              Before you decide,
              <br />
              <span className="text-primary">let three AIs argue.</span>
            </h1>
            <p className="text-muted-foreground mt-3 text-sm font-medium">
              Drop in any startup decision. Gemini, GPT-5, and Claude debate in two rounds, then a
              neutral judge delivers the verdict.
            </p>
            {company ? (
              <div className="mt-3 inline-flex items-center gap-2 text-[11px] uppercase tracking-widest text-primary">
                <Building2 className="size-3.5" /> {company.name}
                {company.document_text && <span className="opacity-60">· doc attached</span>}
              </div>
            ) : (
              <button
                onClick={onAskAddCompany}
                className="mt-3 inline-flex items-center gap-1.5 text-[11px] uppercase tracking-widest text-muted-foreground hover:text-primary transition"
              >
                <Plus className="size-3.5" /> Add a company for context & history
              </button>
            )}
          </div>

          <label className="block">
            <span className="text-xs uppercase tracking-widest text-muted-foreground">
              The decision
            </span>
            <textarea
              value={decision}
              onChange={(e) => setDecision(e.target.value)}
              placeholder="Should we raise a seed round now or wait 6 months to hit $30k MRR first?"
              rows={4}
              className="mt-2 w-full rounded-xl bg-card border border-border p-4 text-sm font-medium outline-none focus:border-primary transition resize-none"
            />
          </label>

          <label className="block">
            <span className="text-xs uppercase tracking-widest text-muted-foreground">
              Context (optional)
            </span>
            <textarea
              value={context}
              onChange={(e) => setContext(e.target.value)}
              placeholder="B2B SaaS. 12 customers. $8k MRR growing 20%/mo. 14 months of runway."
              rows={3}
              className="mt-2 w-full rounded-xl bg-card border border-border p-4 text-sm font-medium outline-none focus:border-primary transition resize-none"
            />
          </label>

          <button
            onClick={run}
            disabled={loading || decision.trim().length < 4}
            className="group inline-flex items-center gap-2 bg-primary text-primary-foreground rounded-full px-6 py-3 text-sm disabled:opacity-50 disabled:cursor-not-allowed glow-primary"
          >
            {loading ? (
              <>
                <Loader2 className="size-4 animate-spin" /> Debating…
              </>
            ) : (
              <>
                Start the debate
                <ArrowRight className="size-4 group-hover:translate-x-0.5 transition" />
              </>
            )}
          </button>

          {error && <div className="text-destructive text-sm">{error}</div>}
        </section>

        <section>
          {loading && <DebateSkeleton />}
          {!loading && !result && <DebateEmptyState />}
          {result && <DebateResultView result={result} />}
        </section>
      </div>

      {company && history.length > 0 && (
        <DebateHistory
          rows={history}
          companyName={company.name}
          onOpen={(row) => {
            setDecision(row.decision);
            setContext(row.context ?? "");
            setResult(row.result);
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
        />
      )}
    </div>
  );
}

function DebateHistory({
  rows,
  companyName,
  onOpen,
}: {
  rows: DebateRow[];
  companyName: string;
  onOpen: (row: DebateRow) => void;
}) {
  return (
    <section>
      <div className="flex items-center gap-2 mb-3 text-xs uppercase tracking-widest text-muted-foreground">
        <History className="size-3.5" /> Last {rows.length} debates · {companyName}
      </div>
      <ul className="grid sm:grid-cols-2 gap-3">
        {rows.map((r) => (
          <li key={r.id}>
            <button
              onClick={() => onOpen(r)}
              className="w-full text-left rounded-2xl border border-border bg-card p-4 hover:border-primary transition"
            >
              <div className="text-[11px] text-muted-foreground mb-1">
                {new Date(r.created_at).toLocaleString()}
              </div>
              <div className="text-sm font-medium line-clamp-2">{r.decision}</div>
              <div className="text-xs text-muted-foreground line-clamp-2 mt-2">
                {r.result.verdict.split("\n")[0]}
              </div>
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}

function DebateEmptyState() {
  return (
    <div className="border border-dashed border-border rounded-2xl p-8 text-center text-sm text-muted-foreground h-full flex flex-col items-center justify-center gap-4">
      <div className="flex gap-3">
        {(["Gemini", "GPT-5", "Claude"] as const).map((s) => (
          <div
            key={s}
            className="px-3 py-1.5 rounded-full text-xs"
            style={{
              color: SPEAKER_COLOR[s],
              borderColor: SPEAKER_COLOR[s],
              borderWidth: 1,
            }}
          >
            {s}
          </div>
        ))}
      </div>
      <p>Awaiting your decision.</p>
    </div>
  );
}

function DebateSkeleton() {
  return (
    <div className="border border-border rounded-2xl p-8 h-full flex flex-col items-center justify-center gap-4 text-muted-foreground">
      <Sparkles className="size-6 text-primary animate-pulse" />
      <div className="text-sm">Three models are thinking…</div>
      <div className="pulse-dot text-primary flex gap-1">
        <span /> <span /> <span />
      </div>
    </div>
  );
}

function TurnCard({ turn }: { turn: Turn }) {
  const color = SPEAKER_COLOR[turn.speaker] ?? "var(--foreground)";
  return (
    <div
      className="rounded-2xl p-5 bg-card border"
      style={{ borderColor: `color-mix(in oklab, ${color} 35%, transparent)` }}
    >
      <div className="text-[11px] uppercase tracking-widest mb-2" style={{ color }}>
        {turn.speaker}
      </div>
      <p className="text-sm leading-relaxed font-medium text-foreground/90">{turn.text}</p>
    </div>
  );
}

function DebateResultView({ result }: { result: DebateResult }) {
  return (
    <div className="space-y-8">
      <RoundBlock label="Round 1 — Opening takes" turns={result.round1} />
      <RoundBlock label="Round 2 — Rebuttals" turns={result.round2} />
      <div className="rounded-2xl p-6 bg-primary text-primary-foreground glow-primary">
        <div className="text-[11px] uppercase tracking-widest opacity-70 mb-2">Final verdict</div>
        <pre className="whitespace-pre-wrap text-sm leading-relaxed font-sans">
          {result.verdict}
        </pre>
      </div>
    </div>
  );
}

function RoundBlock({ label, turns }: { label: string; turns: Turn[] }) {
  return (
    <div>
      <div className="text-xs uppercase tracking-widest text-muted-foreground mb-3">{label}</div>
      <div className="grid gap-3">
        {turns.map((t, i) => (
          <TurnCard key={i} turn={t} />
        ))}
      </div>
    </div>
  );
}

/* ============================== PITCH DECK ============================== */

function DeckPanel({
  company,
  onConsumed,
}: {
  company: Company | null;
  onConsumed: () => Promise<void> | void;
}) {
  const [brand, setBrand] = useState("");
  const [loading, setLoading] = useState(false);
  const [parsing, setParsing] = useState(false);
  const [deck, setDeck] = useState<Deck | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [templateId, setTemplateId] = useState<TemplateId>("midnight");
  

  // Prefill from selected company's doc
  useEffect(() => {
    if (company?.document_text && !brand) {
      setBrand(`COMPANY: ${company.name}\n\n${company.document_text}`);
    }
  }, [company, brand]);

  const onFile = async (file: File) => {
    setError(null);
    setParsing(true);
    try {
      const text = await parseFileToText(file);
      if (text.length < 20) throw new Error("Couldn't extract enough text from that file.");
      setBrand(text);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn't read that file.");
    } finally {
      setParsing(false);
    }
  };

  const generate = async () => {
    setLoading(true);
    setError(null);
    setDeck(null);
    try {
      const { authedFetch, handleQuotaResponse } = await import("@/lib/api-client");
      const res = await authedFetch("/api/pitch-deck", {
        method: "POST",
        body: JSON.stringify({ brand, templateId }),
      });
      const quotaMsg = await handleQuotaResponse(res, "deck");
      if (quotaMsg) throw new Error(quotaMsg);
      if (!res.ok) throw new Error(await res.text());
      await onConsumed();
      const data = (await res.json()) as Deck;
      setDeck({ ...data, templateId });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="space-y-8">
      {!deck && (
        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <h1 className="text-4xl leading-tight">
              From brand doc to
              <br />
              <span className="text-primary">pitch deck in 30s.</span>
            </h1>
            <p className="text-muted-foreground mt-3 text-sm font-medium">
              Paste or upload your brand identity. Super Brain generates a 10-slide investor deck
              you can download as a PDF.
            </p>
            {company && (
              <div className="mt-3 inline-flex items-center gap-2 text-[11px] uppercase tracking-widest text-primary">
                <Building2 className="size-3.5" /> {company.name}
              </div>
            )}

            <label className="mt-6 inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-xs cursor-pointer hover:border-primary transition">
              {parsing ? (
                <>
                  <Loader2 className="size-3.5 animate-spin" /> Reading file…
                </>
              ) : (
                <>Upload .pdf, .docx, .txt or .md</>
              )}
              <input
                type="file"
                accept=".pdf,.docx,.doc,.txt,.md,.markdown"
                className="hidden"
                disabled={parsing}
                onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])}
              />
            </label>
            {brand && !parsing && (
              <div className="mt-2 text-[11px] text-muted-foreground">
                Loaded {brand.length.toLocaleString()} characters.
              </div>
            )}

            <div className="mt-6">
              <span className="text-xs uppercase tracking-widest text-muted-foreground">
                Template
              </span>
              <div className="mt-3 grid grid-cols-2 gap-2">
                {(Object.values(TEMPLATES) as DeckTemplate[]).map((t) => {
                  const active = templateId === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setTemplateId(t.id)}
                      className={`group text-left rounded-xl border p-3 transition ${
                        active
                          ? "border-primary ring-1 ring-primary"
                          : "border-border hover:border-primary/60"
                      }`}
                    >
                      <TemplateThumb t={t} />
                      <div className="mt-2 text-xs font-medium">{t.name}</div>
                      <div className="text-[10px] text-muted-foreground leading-snug">
                        {t.description}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>


          <div className="space-y-3">
            <textarea
              value={brand}
              onChange={(e) => setBrand(e.target.value)}
              placeholder="Paste your brand identity here — mission, audience, product, voice, differentiators, traction, team…"
              rows={12}
              className="w-full rounded-xl bg-card border border-border p-4 text-sm font-medium outline-none focus:border-primary transition resize-none"
            />
            <button
              onClick={generate}
              disabled={loading || brand.trim().length < 20}
              className="inline-flex items-center gap-2 bg-primary text-primary-foreground rounded-full px-6 py-3 text-sm disabled:opacity-50 disabled:cursor-not-allowed glow-primary"
            >
              {loading ? (
                <>
                  <Loader2 className="size-4 animate-spin" /> Generating…
                </>
              ) : (
                <>
                  Generate deck <ArrowRight className="size-4" />
                </>
              )}
            </button>
            {error && <div className="text-destructive text-sm">{error}</div>}
          </div>
        </div>
      )}

      {deck && <DeckView deck={deck} onReset={() => setDeck(null)} />}
    </div>
  );
}

function DeckView({ deck, onReset }: { deck: Deck; onReset: () => void }) {
  const [busy, setBusy] = useState<"pdf" | "pptx" | "docx" | null>(null);

  const run = async (kind: "pdf" | "pptx" | "docx") => {
    setBusy(kind);
    try {
      if (kind === "pdf") await downloadDeckPdf(deck);
      else if (kind === "pptx") await downloadDeckPptx(deck);
      else await downloadDeckDocx(deck);
    } catch (e) {
      console.error(e);
    } finally {
      setBusy(null);
    }
  };

  const btn =
    "inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-xs hover:border-primary transition disabled:opacity-50 disabled:cursor-not-allowed";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap no-print">
        <div>
          <div className="text-xs uppercase tracking-widest text-muted-foreground">Your deck</div>
          <h2 className="text-2xl">{deck.company}</h2>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={onReset} className={btn}>
            New deck
          </button>
          <button onClick={() => run("pptx")} disabled={!!busy} className={btn}>
            {busy === "pptx" ? <Loader2 className="size-3.5 animate-spin" /> : <Presentation className="size-3.5" />}
            .pptx
          </button>
          <button onClick={() => run("docx")} disabled={!!busy} className={btn}>
            {busy === "docx" ? <Loader2 className="size-3.5 animate-spin" /> : <FileType className="size-3.5" />}
            .docx
          </button>
          <button
            onClick={() => run("pdf")}
            disabled={!!busy}
            className="inline-flex items-center gap-2 bg-primary text-primary-foreground rounded-full px-4 py-2 text-xs glow-primary disabled:opacity-50"
          >
            {busy === "pdf" ? <Loader2 className="size-3.5 animate-spin" /> : <FileText className="size-3.5" />}
            .pdf
          </button>
        </div>
      </div>

      <div className="grid gap-5">
        {deck.slides.map((s, i) => (
          <SlideCard
            key={i}
            index={i}
            slide={s}
            company={deck.company}
            tagline={deck.tagline}
            template={getTemplate(deck.templateId)}
          />
        ))}
      </div>
    </div>
  );
}

function SlideCard({
  index,
  slide,
  company,
  tagline,
  template,
}: {
  index: number;
  slide: Slide;
  company: string;
  tagline: string;
  template: DeckTemplate;
}) {
  const t = template;
  const headerRule =
    t.variant === "brutalist"
      ? { borderTop: `3px solid #${t.accent}` }
      : t.variant === "editorial"
        ? { borderTop: `1px solid #${t.slideFg}` }
        : undefined;

  return (
    <div
      className="slide-print rounded-2xl border border-border overflow-hidden aspect-[16/9] flex flex-col p-8"
      style={{
        background: `#${t.slideBg}`,
        color: `#${t.slideFg}`,
        fontFamily: `'${t.bodyFont}', system-ui, sans-serif`,
      }}
    >
      <div
        className="flex items-center justify-between text-[11px] uppercase tracking-[0.2em]"
        style={{ color: `#${t.slideMuted}` }}
      >
        <span>
          {String(index + 1).padStart(2, "0")} / {company}
        </span>
        <span style={{ color: `#${t.accent}` }}>{t.name}</span>
      </div>
      {headerRule && <div className="mt-3" style={headerRule} />}
      <div className="flex-1 flex flex-col justify-center">
        <h3
          className="leading-tight"
          style={{
            fontFamily: `'${t.headingFont}', Georgia, serif`,
            fontWeight: 700,
            fontSize: t.variant === "brutalist" ? "3.25rem" : "2.25rem",
            color: `#${t.slideFg}`,
            letterSpacing: t.variant === "brutalist" ? "-0.02em" : "normal",
          }}
        >
          {slide.title}
        </h3>
        {slide.subtitle && (
          <p
            className="mt-2 text-sm"
            style={{
              color: `#${t.slideMuted}`,
              fontStyle: t.variant === "editorial" ? "italic" : "normal",
            }}
          >
            {slide.subtitle}
          </p>
        )}
        <ul className="mt-6 space-y-2">
          {slide.bullets.map((b, i) => (
            <li key={i} className="flex gap-3 text-sm font-medium">
              <span style={{ color: `#${t.accent}` }}>{t.bullet}</span>
              <span style={{ color: `#${t.slideFg}` }}>{b}</span>
            </li>
          ))}
        </ul>
      </div>
      <div className="text-[10px] mt-4" style={{ color: `#${t.slideMuted}` }}>
        {tagline}
      </div>
    </div>
  );
}

function TemplateThumb({ t }: { t: DeckTemplate }) {
  return (
    <div
      className="rounded-md aspect-[16/9] p-2 flex flex-col justify-between overflow-hidden"
      style={{
        background: `#${t.slideBg}`,
        color: `#${t.slideFg}`,
        fontFamily: `'${t.headingFont}', serif`,
      }}
    >
      <div
        className="text-[7px] tracking-widest uppercase"
        style={{ color: `#${t.accent}` }}
      >
        {t.name}
      </div>
      <div
        className="text-[10px] font-bold leading-tight"
        style={{ color: `#${t.slideFg}` }}
      >
        The big idea.
      </div>
      <div className="flex items-center gap-1" style={{ color: `#${t.slideMuted}` }}>
        <span style={{ color: `#${t.accent}` }}>{t.bullet}</span>
        <span className="text-[7px]">Why it matters now</span>
      </div>
    </div>
  );
}

