import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/login")({
  component: LoginPage,
  head: () => ({
    meta: [
      { title: "Sign in — Suprbrain" },
      { name: "description", content: "Sign in to Suprbrain to run multi-model AI debates on your startup decisions and generate investor-ready pitch decks." },
      { property: "og:title", content: "Sign in — Suprbrain" },
      { property: "og:description", content: "Access your AI boardroom — Claude, Gemini, and ChatGPT debating your startup decisions." },
      { property: "og:url", content: "https://suprbrain.lovable.app/login" },
      { name: "robots", content: "noindex" },
    ],
  }),
});

function LoginPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/app" });
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      if (session) navigate({ to: "/app" });
    });
    return () => sub.subscription.unsubscribe();
  }, [navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setInfo(null);
    try {
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        if (!data.session) {
          setInfo("Check your email — we sent you a verification link to confirm your account.");
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Authentication failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-neural flex items-center justify-center px-6">
      <div className="w-full max-w-md">
        <Link to="/" className="block text-center mb-8">
          <div className="text-2xl">Suprbrain</div>
          <div className="text-[11px] text-muted-foreground uppercase tracking-widest mt-1">
            Three minds. One decision.
          </div>
        </Link>

        <h1 className="sr-only">Sign in to Suprbrain</h1>
        <div className="rounded-2xl bg-card border border-border p-7">
          <div className="flex gap-1 p-1 rounded-full bg-secondary text-sm mb-6">
            <button
              type="button"
              onClick={() => { setMode("signin"); setError(null); setInfo(null); }}
              className={`flex-1 px-4 py-1.5 rounded-full transition ${
                mode === "signin" ? "bg-primary text-primary-foreground" : "text-muted-foreground"
              }`}
            >
              Sign in
            </button>
            <button
              type="button"
              onClick={() => { setMode("signup"); setError(null); setInfo(null); }}
              className={`flex-1 px-4 py-1.5 rounded-full transition ${
                mode === "signup" ? "bg-primary text-primary-foreground" : "text-muted-foreground"
              }`}
            >
              Create account
            </button>
          </div>

          <form onSubmit={submit} className="space-y-4">
            <label className="block">
              <span className="text-xs uppercase tracking-widest text-muted-foreground">Email</span>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-2 w-full rounded-xl bg-background border border-border p-3 text-sm outline-none focus:border-primary transition"
              />
            </label>
            <label className="block">
              <span className="text-xs uppercase tracking-widest text-muted-foreground">Password</span>
              <input
                type="password"
                required
                minLength={8}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-2 w-full rounded-xl bg-background border border-border p-3 text-sm outline-none focus:border-primary transition"
              />
            </label>

            {error && <div className="text-destructive text-sm">{error}</div>}
            {info && <div className="text-primary text-sm">{info}</div>}

            <button
              type="submit"
              disabled={loading}
              className="w-full inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground rounded-full px-6 py-3 text-sm disabled:opacity-50 glow-primary"
            >
              {loading ? <><Loader2 className="size-4 animate-spin" /> Working…</> : mode === "signin" ? "Sign in" : "Create account"}
            </button>
          </form>

          {mode === "signup" && (
            <p className="text-[11px] text-muted-foreground mt-4 text-center">
              We'll email you a link to verify your address before you can sign in.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
