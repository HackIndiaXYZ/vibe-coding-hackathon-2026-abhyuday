import { useRef, useState } from "react";

import { Loader2, ArrowRight, Building2, TrendingUp, AlertTriangle, Sparkles, Eye, EyeOff } from "lucide-react";
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from "recharts";
import { parseFileToText } from "@/lib/parse-file";

type Company = {
  id: string;
  name: string;
  document_text: string | null;
  document_filename: string | null;
};

type YearPoint = { year: number; revenue: number; low: number; high: number };
type ModelProjection = {
  model: "Gemini" | "ChatGPT" | "Claude";
  summary: string;
  yearly: YearPoint[];
};
type Projection = {
  company: string;
  currency: string;
  baseYear: number;
  summary: string;
  assumptions: string[];
  drivers: string[];
  risks: string[];
  yearly: YearPoint[];
  modelProjections?: ModelProjection[];
};

const HORIZONS = [3, 5, 7, 10];

function formatMoney(n: number, currency: string) {
  const abs = Math.abs(n);
  let val = n;
  let suffix = "";
  if (abs >= 1_000_000_000) {
    val = n / 1_000_000_000;
    suffix = "B";
  } else if (abs >= 1_000_000) {
    val = n / 1_000_000;
    suffix = "M";
  } else if (abs >= 1_000) {
    val = n / 1_000;
    suffix = "K";
  }
  return `${currency} ${val.toLocaleString(undefined, { maximumFractionDigits: 1 })}${suffix}`;
}

export function RevenuePanel({
  company,
  onConsumed,
}: {
  company: Company | null;
  onConsumed: () => Promise<void> | void;
}) {
  const [history, setHistory] = useState("");
  const [fileName, setFileName] = useState<string | null>(null);
  const [parsing, setParsing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [horizon, setHorizon] = useState<number>(5);
  const [error, setError] = useState<string | null>(null);
  const [projection, setProjection] = useState<Projection | null>(null);
  

  const onFile = async (file: File) => {
    setError(null);
    setParsing(true);
    try {
      const text = await parseFileToText(file);
      if (text.length < 20) throw new Error("Couldn't extract enough text from that file.");
      setHistory(text);
      setFileName(file.name);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn't read that file.");
    } finally {
      setParsing(false);
    }
  };

  const run = async () => {
    setLoading(true);
    setError(null);
    setProjection(null);
    try {
      const mergedHistory = [
        company?.document_text
          ? `COMPANY REFERENCE DOC (${company.name}):\n${company.document_text}`
          : "",
        history.trim() ? `FINANCIAL HISTORY:\n${history.trim()}` : "",
      ]
        .filter(Boolean)
        .join("\n\n---\n\n");

      const { authedFetch, handleQuotaResponse } = await import("@/lib/api-client");
      const res = await authedFetch("/api/revenue", {
        method: "POST",
        body: JSON.stringify({
          history: mergedHistory,
          horizon,
          companyName: company?.name,
        }),
      });
      const quotaMsg = await handleQuotaResponse(res, "revenue");
      if (quotaMsg) throw new Error(quotaMsg);
      if (!res.ok) throw new Error(await res.text());
      await onConsumed();
      setProjection((await res.json()) as Projection);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="space-y-8">
      {!projection && (
        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <h1 className="text-4xl leading-tight">
              From P&L to
              <br />
              <span className="text-primary">a 10-year forecast.</span>
            </h1>
            <p className="text-muted-foreground mt-3 text-sm font-medium">
              Upload your finance history (.pdf or .docx). Suprbrain reads it and projects revenue
              with a confidence band, drivers, and risks.
            </p>
            {company && (
              <div className="mt-3 inline-flex items-center gap-2 text-[11px] uppercase tracking-widest text-primary">
                <Building2 className="size-3.5" /> {company.name}
              </div>
            )}

            <div className="mt-6">
              <span className="text-xs uppercase tracking-widest text-muted-foreground">
                Projection horizon
              </span>
              <div className="mt-2 flex gap-2 flex-wrap">
                {HORIZONS.map((y) => (
                  <button
                    key={y}
                    onClick={() => setHorizon(y)}
                    className={`px-4 py-1.5 rounded-full text-xs border transition ${
                      horizon === y
                        ? "bg-primary text-primary-foreground border-primary"
                        : "border-border text-muted-foreground hover:border-primary"
                    }`}
                  >
                    {y} years
                  </button>
                ))}
              </div>
            </div>

            <label className="mt-6 inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-xs cursor-pointer hover:border-primary transition">
              {parsing ? (
                <>
                  <Loader2 className="size-3.5 animate-spin" /> Reading file…
                </>
              ) : (
                <>Upload .pdf, .docx, .txt or .md</>
              )}
              <input
                type="file"
                accept=".pdf,.docx,.doc,.txt,.md,.markdown"
                className="hidden"
                disabled={parsing}
                onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])}
              />
            </label>
            {fileName && !parsing && (
              <div className="mt-2 text-[11px] text-muted-foreground">
                {fileName} — {history.length.toLocaleString()} characters loaded.
              </div>
            )}
          </div>

          <div className="space-y-3">
            <textarea
              value={history}
              onChange={(e) => {
                setHistory(e.target.value);
                if (fileName) setFileName(null);
              }}
              placeholder="Or paste finance history: yearly revenue, COGS, growth rates, customer counts, churn, ARPU, segments…"
              rows={12}
              className="w-full rounded-xl bg-card border border-border p-4 text-sm font-medium outline-none focus:border-primary transition resize-none"
            />
            <button
              onClick={run}
              disabled={loading || history.trim().length < 20}
              className="inline-flex items-center gap-2 bg-primary text-primary-foreground rounded-full px-6 py-3 text-sm disabled:opacity-50 disabled:cursor-not-allowed glow-primary"
            >
              {loading ? (
                <>
                  <Loader2 className="size-4 animate-spin" /> Projecting…
                </>
              ) : (
                <>
                  Project revenue <ArrowRight className="size-4" />
                </>
              )}
            </button>
            {error && <div className="text-destructive text-sm">{error}</div>}
          </div>
        </div>
      )}

      {loading && !projection && (
        <div className="border border-border rounded-2xl p-12 flex flex-col items-center justify-center gap-4 text-muted-foreground">
          <Sparkles className="size-6 text-primary animate-pulse" />
          <div className="text-sm">Gemini, ChatGPT, and Claude are modeling {horizon} years…</div>
        </div>
      )}

      {projection && <ProjectionView projection={projection} onReset={() => setProjection(null)} />}
    </div>
  );
}

function ProjectionView({ projection, onReset }: { projection: Projection; onReset: () => void }) {
  const modelPoint = (model: ModelProjection["model"], year: number) =>
    projection.modelProjections?.find((p) => p.model === model)?.yearly.find((y) => y.year === year)
      ?.revenue ?? null;
  const data = projection.yearly.map((y) => ({
    year: y.year,
    revenue: y.revenue,
    low: y.low,
    high: y.high,
    band: Math.max(0, y.high - y.low),
    gemini: modelPoint("Gemini", y.year),
    chatgpt: modelPoint("ChatGPT", y.year),
    claude: modelPoint("Claude", y.year),
  }));
  const baseIndex = data.findIndex((d) => d.year === projection.baseYear);
  const final = data[data.length - 1];
  const base = data[baseIndex >= 0 ? baseIndex : 0];
  const yearsSpan = final.year - base.year;
  const cagr =
    yearsSpan > 0 && base.revenue > 0
      ? (Math.pow(final.revenue / base.revenue, 1 / yearsSpan) - 1) * 100
      : 0;

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <div className="text-xs uppercase tracking-widest text-muted-foreground">
            Revenue projection
          </div>
          <h2 className="text-2xl">{projection.company}</h2>
        </div>
        <button
          onClick={onReset}
          className="rounded-full border border-border px-4 py-2 text-xs hover:border-primary transition"
        >
          New projection
        </button>
      </div>

      <div className="grid sm:grid-cols-3 gap-3">
        <Stat label={`Base ${base.year}`} value={formatMoney(base.revenue, projection.currency)} />
        <Stat
          label={`Projected ${final.year}`}
          value={formatMoney(final.revenue, projection.currency)}
        />
        <Stat
          label={`CAGR (${yearsSpan}y)`}
          value={`${cagr >= 0 ? "+" : ""}${cagr.toFixed(1)}%`}
          accent
        />
      </div>

      <ChartCard data={data} projection={projection} />

      <div className="rounded-2xl border border-border bg-card p-5">
        <div className="text-xs uppercase tracking-widest text-muted-foreground mb-3">
          Yearly breakdown
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-[11px] uppercase tracking-widest text-muted-foreground">
              <tr className="border-b border-border">
                <th className="text-left py-2 pr-4">Year</th>
                <th className="text-right py-2 pr-4">Revenue</th>
                <th className="text-right py-2 pr-4">Low</th>
                <th className="text-right py-2">High</th>
              </tr>
            </thead>
            <tbody>
              {data.map((d) => (
                <tr key={d.year} className="border-b border-border/50 last:border-0">
                  <td className="py-2 pr-4 font-medium">
                    {d.year}
                    {d.year === projection.baseYear && (
                      <span className="ml-2 text-[10px] uppercase tracking-widest text-muted-foreground">
                        base
                      </span>
                    )}
                  </td>
                  <td className="py-2 pr-4 text-right font-medium">
                    {formatMoney(d.revenue, projection.currency)}
                  </td>
                  <td className="py-2 pr-4 text-right text-muted-foreground">
                    {formatMoney(d.low, projection.currency)}
                  </td>
                  <td className="py-2 text-right text-muted-foreground">
                    {formatMoney(d.high, projection.currency)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="rounded-2xl p-6 bg-primary text-primary-foreground glow-primary">
        <div className="text-[11px] uppercase tracking-widest opacity-70 mb-2">Summary</div>
        <p className="text-sm leading-relaxed">{projection.summary}</p>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <ListCard
          icon={<Sparkles className="size-3.5" />}
          label="Assumptions"
          items={projection.assumptions}
        />
        <ListCard
          icon={<TrendingUp className="size-3.5" />}
          label="Growth drivers"
          items={projection.drivers}
        />
        <ListCard
          icon={<AlertTriangle className="size-3.5" />}
          label="Risks"
          items={projection.risks}
        />
      </div>
    </div>
  );
}

type ChartDatum = {
  year: number;
  revenue: number;
  low: number;
  high: number;
  band: number;
  gemini: number | null;
  chatgpt: number | null;
  claude: number | null;
};

function ChartCard({ data, projection }: { data: ChartDatum[]; projection: Projection }) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState({ gemini: true, chatgpt: true, claude: true });

  const toggle = (key: "gemini" | "chatgpt" | "claude") =>
    setVisible((v) => ({ ...v, [key]: !v[key] }));

  const toggles: { key: "gemini" | "chatgpt" | "claude"; label: string; color: string }[] = [
    { key: "gemini", label: "Gemini", color: "var(--gemini)" },
    { key: "chatgpt", label: "ChatGPT", color: "var(--gpt)" },
    { key: "claude", label: "Claude", color: "var(--claude)" },
  ];


  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <div className="text-xs uppercase tracking-widest text-muted-foreground">
          3-model revenue projection · yellow average · {projection.currency}
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {toggles.map((t) => {
            const active = visible[t.key];
            return (
              <button
                key={t.key}
                onClick={() => toggle(t.key)}
                className={`inline-flex items-center gap-1.5 text-[10px] uppercase tracking-widest px-2.5 py-1 rounded-full border transition ${
                  active
                    ? "border-current"
                    : "border-border text-muted-foreground hover:border-primary"
                }`}
                style={active ? { color: t.color, borderColor: t.color } : {}}
                title={active ? `Hide ${t.label}` : `Show ${t.label}`}
              >
                {active ? <Eye className="size-3" /> : <EyeOff className="size-3" />}
                {t.label}
              </button>
            );
          })}
        </div>
      </div>
      <div ref={wrapRef} className="h-80 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 10, right: 10, bottom: 0, left: 0 }}>
            <defs>
              <linearGradient id="bandFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.26} />
                <stop offset="100%" stopColor="var(--primary)" stopOpacity={0.04} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="year" stroke="var(--muted-foreground)" fontSize={11} />
            <YAxis
              stroke="var(--muted-foreground)"
              fontSize={11}
              tickFormatter={(v) => formatMoney(Number(v), projection.currency)}
              width={70}
            />
            <Tooltip
              contentStyle={{
                background: "var(--card)",
                border: "1px solid var(--border)",
                borderRadius: 12,
                fontSize: 12,
              }}
              formatter={(value: number, name) => [
                formatMoney(Number(value), projection.currency),
                name === "revenue"
                  ? "Average projection"
                  : name === "gemini"
                    ? "Gemini"
                    : name === "chatgpt"
                      ? "ChatGPT"
                      : name === "claude"
                        ? "Claude"
                        : name === "low"
                          ? "Low"
                          : name === "high"
                            ? "High"
                            : name,
              ]}
            />
            <Legend
              verticalAlign="top"
              height={34}
              iconType="plainline"
              wrapperStyle={{ fontSize: 11 }}
            />
            <Area
              type="monotone"
              dataKey="high"
              stroke="transparent"
              fill="url(#bandFill)"
              name="High"
              isAnimationActive={false}
            />
            <Area
              type="monotone"
              dataKey="low"
              stroke="transparent"
              fill="var(--card)"
              name="Low"
              isAnimationActive={false}
            />
            {visible.gemini && (
              <Line
                type="monotone"
                dataKey="gemini"
                name="Gemini"
                stroke="var(--gemini)"
                strokeWidth={1.8}
                strokeDasharray="5 5"
                dot={{ r: 2.5, fill: "var(--gemini)" }}
                connectNulls
                isAnimationActive={false}
              />
            )}
            {visible.chatgpt && (
              <Line
                type="monotone"
                dataKey="chatgpt"
                name="ChatGPT"
                stroke="var(--gpt)"
                strokeWidth={1.8}
                strokeDasharray="5 5"
                dot={{ r: 2.5, fill: "var(--gpt)" }}
                connectNulls
                isAnimationActive={false}
              />
            )}
            {visible.claude && (
              <Line
                type="monotone"
                dataKey="claude"
                name="Claude"
                stroke="var(--claude)"
                strokeWidth={1.8}
                strokeDasharray="5 5"
                dot={{ r: 2.5, fill: "var(--claude)" }}
                connectNulls
                isAnimationActive={false}
              />
            )}
            <Line
              type="monotone"
              dataKey="revenue"
              name="Average projection"
              stroke="var(--primary)"
              strokeWidth={3.2}
              dot={{ r: 3.5, fill: "var(--primary)" }}
              activeDot={{ r: 5 }}
              isAnimationActive={false}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div
      className={`rounded-2xl border p-4 ${
        accent ? "border-primary bg-primary/5" : "border-border bg-card"
      }`}
    >
      <div className="text-[11px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className={`mt-1 text-xl font-medium ${accent ? "text-primary" : ""}`}>{value}</div>
    </div>
  );
}

function ListCard({
  icon,
  label,
  items,
}: {
  icon: React.ReactNode;
  label: string;
  items: string[];
}) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="flex items-center gap-1.5 text-[11px] uppercase tracking-widest text-muted-foreground mb-3">
        {icon} {label}
      </div>
      <ul className="space-y-2">
        {items.map((it, i) => (
          <li key={i} className="flex gap-2 text-sm">
            <span className="text-primary">→</span>
            <span className="font-medium text-foreground/90">{it}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
