CREATE TABLE public.debates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  company_id UUID REFERENCES public.companies(id) ON DELETE CASCADE,
  decision TEXT NOT NULL,
  context TEXT,
  result JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.debates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own debates" ON public.debates FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users insert own debates" ON public.debates FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users delete own debates" ON public.debates FOR DELETE USING (auth.uid() = user_id);

CREATE INDEX idx_debates_user_company ON public.debates(user_id, company_id, created_at DESC);