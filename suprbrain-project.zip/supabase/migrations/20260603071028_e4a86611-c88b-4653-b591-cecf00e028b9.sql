-- Tighten RLS: with RLS enabled and no write policies, authenticated/anon writes
-- are already denied (service_role bypasses RLS regardless). Add explicit
-- restrictive deny policies for clarity and to satisfy security review, and add
-- a missing UPDATE policy on debates scoped to the owner.

-- subscriptions: explicitly deny client writes
CREATE POLICY "Deny client inserts on subscriptions"
ON public.subscriptions AS RESTRICTIVE FOR INSERT TO authenticated, anon
WITH CHECK (false);

CREATE POLICY "Deny client updates on subscriptions"
ON public.subscriptions AS RESTRICTIVE FOR UPDATE TO authenticated, anon
USING (false) WITH CHECK (false);

CREATE POLICY "Deny client deletes on subscriptions"
ON public.subscriptions AS RESTRICTIVE FOR DELETE TO authenticated, anon
USING (false);

-- transactions: explicitly deny client writes
CREATE POLICY "Deny client inserts on transactions"
ON public.transactions AS RESTRICTIVE FOR INSERT TO authenticated, anon
WITH CHECK (false);

CREATE POLICY "Deny client updates on transactions"
ON public.transactions AS RESTRICTIVE FOR UPDATE TO authenticated, anon
USING (false) WITH CHECK (false);

CREATE POLICY "Deny client deletes on transactions"
ON public.transactions AS RESTRICTIVE FOR DELETE TO authenticated, anon
USING (false);

-- usage_counters: explicitly deny client writes (server increments via service role)
CREATE POLICY "Deny client inserts on usage_counters"
ON public.usage_counters AS RESTRICTIVE FOR INSERT TO authenticated, anon
WITH CHECK (false);

CREATE POLICY "Deny client updates on usage_counters"
ON public.usage_counters AS RESTRICTIVE FOR UPDATE TO authenticated, anon
USING (false) WITH CHECK (false);

CREATE POLICY "Deny client deletes on usage_counters"
ON public.usage_counters AS RESTRICTIVE FOR DELETE TO authenticated, anon
USING (false);

-- debates: add missing UPDATE policy scoped to owner
CREATE POLICY "Users update own debates"
ON public.debates FOR UPDATE TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);
