import { AbsoluteFill } from "remotion";
import { TransitionSeries, springTiming } from "@remotion/transitions";
import { fade } from "@remotion/transitions/fade";
import { PersistentBackground } from "./components/Persistent";
import { Scene1Cover } from "./scenes/Scene1Cover";
import { Scene2Problem } from "./scenes/Scene2Problem";
import { Scene3Trio } from "./scenes/Scene3Trio";
import { Scene4Debate } from "./scenes/Scene4Debate";
import { Scene5Features } from "./scenes/Scene5Features";
import { Scene6CTA } from "./scenes/Scene6CTA";
import { fontFamily } from "./theme";

// Durations per scene
const D = [110, 140, 150, 180, 160, 130];
const TRANS = 18;
// Total with overlaps: sum(D) - 5*TRANS
export const TOTAL = D.reduce((a,b)=>a+b,0) - 5 * TRANS;

const t = () => springTiming({ config: { damping: 200 }, durationInFrames: TRANS });

export const MainVideo: React.FC = () => {
  return (
    <AbsoluteFill style={{ fontFamily }}>
      <PersistentBackground />
      <TransitionSeries>
        <TransitionSeries.Sequence durationInFrames={D[0]}><Scene1Cover /></TransitionSeries.Sequence>
        <TransitionSeries.Transition presentation={fade()} timing={t()} />
        <TransitionSeries.Sequence durationInFrames={D[1]}><Scene2Problem /></TransitionSeries.Sequence>
        <TransitionSeries.Transition presentation={fade()} timing={t()} />
        <TransitionSeries.Sequence durationInFrames={D[2]}><Scene3Trio /></TransitionSeries.Sequence>
        <TransitionSeries.Transition presentation={fade()} timing={t()} />
        <TransitionSeries.Sequence durationInFrames={D[3]}><Scene4Debate /></TransitionSeries.Sequence>
        <TransitionSeries.Transition presentation={fade()} timing={t()} />
        <TransitionSeries.Sequence durationInFrames={D[4]}><Scene5Features /></TransitionSeries.Sequence>
        <TransitionSeries.Transition presentation={fade()} timing={t()} />
        <TransitionSeries.Sequence durationInFrames={D[5]}><Scene6CTA /></TransitionSeries.Sequence>
      </TransitionSeries>
    </AbsoluteFill>
  );
};
