import { loadFont } from "@remotion/google-fonts/SpaceGrotesk";

export const { fontFamily } = loadFont("normal", {
  weights: ["400", "500", "700"],
  subsets: ["latin"],
});

export const COLORS = {
  bg: "#0B0A14",
  bg2: "#141232",
  fg: "#F5F3FA",
  muted: "#8B86A8",
  amber: "#F4B73D",      // primary
  claude: "#E8743A",     // orange
  gemini: "#3A92E8",     // blue
  gpt: "#3AE89A",        // mint
  border: "#2A2740",
};
