import { AbsoluteFill, useCurrentFrame, useVideoConfig, spring, interpolate } from "remotion";
import { COLORS } from "../theme";

const QUESTIONS = [
  "Should we raise a $5M seed now?",
  "Pivot to B2B or stay consumer?",
  "Hire 2 engineers or 1 designer?",
  "Ship the agent or polish the core?",
];

export const Scene2Problem: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const headIn = spring({ frame, fps, config: { damping: 18 } });

  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", padding: 80 }}>
      <div style={{
        opacity: headIn,
        transform: `translateY(${interpolate(headIn, [0, 1], [30, 0])}px)`,
        fontSize: 90, fontWeight: 700, color: COLORS.fg, letterSpacing: -2, textAlign: "center",
        lineHeight: 1.05, maxWidth: 1400,
      }}>
        Founders make their hardest <span style={{ color: COLORS.amber }}>calls</span> alone.
      </div>

      <div style={{ marginTop: 60, display: "flex", flexDirection: "column", gap: 18, alignItems: "stretch", width: 900 }}>
        {QUESTIONS.map((q, i) => {
          const delay = 25 + i * 12;
          const s = spring({ frame: frame - delay, fps, config: { damping: 16, stiffness: 140 } });
          return (
            <div key={i} style={{
              opacity: s,
              transform: `translateX(${interpolate(s, [0, 1], [-40, 0])}px)`,
              padding: "22px 28px", borderRadius: 14,
              background: `${COLORS.bg2}CC`,
              border: `1px solid ${COLORS.border}`,
              color: COLORS.fg, fontSize: 28, fontWeight: 500,
              display: "flex", alignItems: "center", gap: 16,
            }}>
              <span style={{ color: COLORS.muted, fontSize: 18, fontWeight: 700, letterSpacing: 2 }}>0{i+1}</span>
              <span style={{ flex: 1 }}>{q}</span>
              <span style={{ color: COLORS.muted, fontSize: 22 }}>?</span>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
