import { AbsoluteFill, useCurrentFrame, useVideoConfig, spring, interpolate } from "remotion";
import { COLORS } from "../theme";

export const Scene6CTA: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const a = spring({ frame, fps, config: { damping: 18 } });
  const b = spring({ frame: frame - 14, fps, config: { damping: 18 } });
  const c = spring({ frame: frame - 28, fps, config: { damping: 16, stiffness: 110 } });
  const pulse = 1 + Math.sin(frame / 8) * 0.02;

  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
      <div style={{
        opacity: a, transform: `translateY(${interpolate(a, [0,1], [-20, 0])}px)`,
        fontSize: 28, color: COLORS.muted, fontWeight: 700, letterSpacing: 5, textTransform: "uppercase",
        marginBottom: 28,
      }}>The boardroom is open</div>

      <div style={{
        opacity: b, transform: `scale(${interpolate(b, [0,1], [0.9, 1])})`,
        fontSize: 180, fontWeight: 700, color: COLORS.fg, letterSpacing: -6, lineHeight: 0.95, textAlign: "center",
        background: `linear-gradient(120deg, ${COLORS.claude}, ${COLORS.amber}, ${COLORS.gemini})`,
        WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
      }}>
        Suprbrain
      </div>

      <div style={{
        opacity: b, marginTop: 24, fontSize: 32, color: COLORS.fg, fontWeight: 500, letterSpacing: -0.5,
        textAlign: "center",
      }}>
        Debate. Decide. Pitch. Project.
      </div>

      <div style={{
        opacity: c, transform: `scale(${pulse})`,
        marginTop: 60, padding: "22px 48px", borderRadius: 14,
        background: COLORS.amber, color: COLORS.bg,
        fontSize: 28, fontWeight: 700, letterSpacing: 0.5,
        boxShadow: `0 20px 60px ${COLORS.amber}66`,
      }}>
        suprbrain.lovable.app
      </div>
    </AbsoluteFill>
  );
};
