import { AbsoluteFill, useCurrentFrame, useVideoConfig, spring, interpolate } from "remotion";
import { COLORS } from "../theme";
import { Orb } from "../components/Persistent";

export const Scene3Trio: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const head = spring({ frame, fps, config: { damping: 18 } });

  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
      <div style={{
        opacity: head,
        transform: `translateY(${interpolate(head, [0, 1], [-20, 0])}px)`,
        fontSize: 28, color: COLORS.muted, fontWeight: 600, letterSpacing: 4, textTransform: "uppercase",
        marginBottom: 20,
      }}>
        Meet your boardroom
      </div>
      <div style={{
        opacity: head,
        fontSize: 96, fontWeight: 700, color: COLORS.fg, letterSpacing: -3, marginBottom: 100,
        textAlign: "center", lineHeight: 1,
      }}>
        Three frontier minds.
      </div>

      <div style={{ position: "relative", width: 1400, height: 360 }}>
        <Orb color={COLORS.claude} x={250} y={180} size={220} delay={20} label="Claude" sub="The Skeptic" />
        <Orb color={COLORS.amber}  x={700} y={180} size={260} delay={28} label="GPT-5"  sub="The Strategist" />
        <Orb color={COLORS.gemini} x={1150} y={180} size={220} delay={36} label="Gemini" sub="The Optimist" />
      </div>
    </AbsoluteFill>
  );
};
