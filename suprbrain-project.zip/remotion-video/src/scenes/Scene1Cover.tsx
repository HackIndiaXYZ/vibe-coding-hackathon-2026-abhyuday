import { AbsoluteFill, useCurrentFrame, useVideoConfig, spring, interpolate } from "remotion";
import { COLORS } from "../theme";

export const Scene1Cover: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const logoIn = spring({ frame, fps, config: { damping: 14, stiffness: 100 } });
  const titleIn = spring({ frame: frame - 12, fps, config: { damping: 18 } });
  const subIn = spring({ frame: frame - 28, fps, config: { damping: 20 } });
  const kickerIn = interpolate(frame, [40, 60], [0, 1], { extrapolateRight: "clamp" });

  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
      <div style={{
        opacity: kickerIn,
        transform: `translateY(${interpolate(kickerIn, [0, 1], [12, 0])}px)`,
        display: "inline-flex", alignItems: "center", gap: 12,
        padding: "8px 18px", borderRadius: 999,
        border: `1px solid ${COLORS.border}`,
        background: `${COLORS.bg2}AA`, backdropFilter: "none",
        color: COLORS.muted, fontSize: 16, fontWeight: 600, letterSpacing: 3, textTransform: "uppercase",
        marginBottom: 40,
      }}>
        <span style={{ width: 8, height: 8, borderRadius: 999, background: COLORS.amber, boxShadow: `0 0 12px ${COLORS.amber}` }} />
        Three AI minds. One decision.
      </div>

      <div style={{
        transform: `scale(${logoIn})`,
        display: "flex", alignItems: "center", gap: 24, marginBottom: 24,
      }}>
        <div style={{
          width: 96, height: 96, borderRadius: 24,
          background: `linear-gradient(135deg, ${COLORS.claude}, ${COLORS.gemini})`,
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: `0 20px 60px ${COLORS.amber}44`,
        }}>
          <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke={COLORS.bg} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 5a3 3 0 1 0-5.99.13M12 5a3 3 0 1 1 5.99.13M12 5v14M6 8a3 3 0 1 0 0 6M18 8a3 3 0 1 1 0 6M6 14a3 3 0 1 0 3 5M18 14a3 3 0 1 1-3 5" />
          </svg>
        </div>
      </div>

      <div style={{
        opacity: titleIn,
        transform: `translateY(${interpolate(titleIn, [0, 1], [30, 0])}px)`,
        fontSize: 140, fontWeight: 700, letterSpacing: -4, color: COLORS.fg,
        lineHeight: 1,
      }}>
        Suprbrain
      </div>
      <div style={{
        opacity: subIn,
        transform: `translateY(${interpolate(subIn, [0, 1], [20, 0])}px)`,
        marginTop: 24, fontSize: 28, color: COLORS.muted, fontWeight: 500, letterSpacing: 0.5,
      }}>
        Your startup's AI boardroom.
      </div>
    </AbsoluteFill>
  );
};
