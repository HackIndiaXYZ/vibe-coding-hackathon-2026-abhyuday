import { AbsoluteFill, useCurrentFrame, useVideoConfig, spring, interpolate } from "remotion";
import { COLORS } from "../theme";

export const Scene5Features: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const head = spring({ frame, fps, config: { damping: 18 } });

  const cards = [
    { title: "Pitch decks", sub: "Investor-ready. .pptx, .pdf, .docx.", color: COLORS.gemini, icon: "▤" },
    { title: "Revenue projections", sub: "3 AI models forecast. Yellow = consensus.", color: COLORS.gpt, icon: "↗" },
    { title: "Decision debates", sub: "Three minds argue. One verdict.", color: COLORS.claude, icon: "◆" },
  ];

  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", padding: 60 }}>
      <div style={{
        opacity: head, fontSize: 80, fontWeight: 700, color: COLORS.fg, letterSpacing: -2,
        textAlign: "center", marginBottom: 60, lineHeight: 1.05, maxWidth: 1400,
      }}>
        One brain. <span style={{ color: COLORS.amber }}>Three superpowers.</span>
      </div>

      <div style={{ display: "flex", gap: 28 }}>
        {cards.map((c, i) => {
          const delay = 18 + i * 14;
          const s = spring({ frame: frame - delay, fps, config: { damping: 15, stiffness: 130 } });
          return (
            <div key={i} style={{
              opacity: s,
              transform: `translateY(${interpolate(s, [0,1], [40, 0])}px) scale(${interpolate(s, [0,1], [0.92, 1])})`,
              width: 380, padding: 36, borderRadius: 20,
              background: `${COLORS.bg2}DD`,
              border: `1px solid ${COLORS.border}`,
              boxShadow: `0 30px 80px -20px ${c.color}44`,
            }}>
              <div style={{
                width: 64, height: 64, borderRadius: 16,
                background: `${c.color}22`,
                color: c.color,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 36, fontWeight: 700, marginBottom: 28,
              }}>{c.icon}</div>
              <div style={{ color: COLORS.fg, fontSize: 32, fontWeight: 700, marginBottom: 12 }}>{c.title}</div>
              <div style={{ color: COLORS.muted, fontSize: 20, lineHeight: 1.45, fontWeight: 500 }}>{c.sub}</div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
