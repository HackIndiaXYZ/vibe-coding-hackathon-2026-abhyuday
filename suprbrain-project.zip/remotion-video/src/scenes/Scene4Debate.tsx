import { AbsoluteFill, useCurrentFrame, useVideoConfig, spring, interpolate } from "remotion";
import { COLORS } from "../theme";

const TURNS = [
  { who: "Gemini", color: COLORS.gemini, text: "Raise now. Market window is open." },
  { who: "GPT-5",  color: COLORS.gpt,    text: "Wait. CAC payback is still 14 months." },
  { who: "Claude", color: COLORS.claude, text: "Fix retention first — funding a leaky bucket." },
  { who: "Verdict",color: COLORS.amber,  text: "Bootstrap 3 months. Hit 110% NDR. Then raise." },
];

export const Scene4Debate: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const head = spring({ frame, fps, config: { damping: 18 } });

  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", padding: 60 }}>
      <div style={{
        opacity: head, transform: `translateY(${interpolate(head, [0,1], [-15,0])}px)`,
        fontSize: 24, color: COLORS.muted, fontWeight: 700, letterSpacing: 4, textTransform: "uppercase", marginBottom: 16,
      }}>Live debate</div>
      <div style={{
        opacity: head, fontSize: 64, fontWeight: 700, color: COLORS.fg, letterSpacing: -1.5, marginBottom: 40,
        textAlign: "center", maxWidth: 1200, lineHeight: 1.1,
      }}>
        They argue. <span style={{ color: COLORS.amber }}>You decide.</span>
      </div>

      <div style={{ width: 1100, display: "flex", flexDirection: "column", gap: 14 }}>
        {TURNS.map((t, i) => {
          const delay = 20 + i * 22;
          const s = spring({ frame: frame - delay, fps, config: { damping: 16, stiffness: 130 } });
          const isVerdict = t.who === "Verdict";
          return (
            <div key={i} style={{
              opacity: s,
              transform: `translateY(${interpolate(s, [0,1], [24, 0])}px)`,
              padding: "20px 26px", borderRadius: 14,
              background: isVerdict ? `${t.color}1F` : `${COLORS.bg2}CC`,
              border: `1px solid ${isVerdict ? `${t.color}88` : COLORS.border}`,
              boxShadow: isVerdict ? `0 0 40px ${t.color}33` : "none",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
                <span style={{ width: 10, height: 10, borderRadius: 999, background: t.color, boxShadow: `0 0 10px ${t.color}` }} />
                <span style={{ color: t.color, fontWeight: 700, fontSize: 16, letterSpacing: 2, textTransform: "uppercase" }}>
                  {isVerdict ? "Final Verdict" : t.who}
                </span>
              </div>
              <div style={{ color: COLORS.fg, fontSize: 26, fontWeight: 500, lineHeight: 1.35 }}>{t.text}</div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
