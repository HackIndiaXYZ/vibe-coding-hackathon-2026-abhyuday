import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, spring } from "remotion";
import { COLORS, fontFamily } from "../theme";

export const PersistentBackground: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  return (
    <AbsoluteFill style={{ background: COLORS.bg, fontFamily }}>
      <AbsoluteFill style={{
        background: `radial-gradient(circle at ${20 + Math.sin(t * 0.3) * 10}% ${30 + Math.cos(t * 0.4) * 10}%, ${COLORS.claude}33 0%, transparent 50%)`,
      }} />
      <AbsoluteFill style={{
        background: `radial-gradient(circle at ${80 + Math.cos(t * 0.35) * 10}% ${70 + Math.sin(t * 0.3) * 10}%, ${COLORS.gemini}33 0%, transparent 50%)`,
      }} />
      <AbsoluteFill style={{
        background: `radial-gradient(circle at 50% 50%, ${COLORS.amber}1A 0%, transparent 60%)`,
      }} />
      {/* subtle grid */}
      <AbsoluteFill style={{
        backgroundImage: `linear-gradient(${COLORS.border}40 1px, transparent 1px), linear-gradient(90deg, ${COLORS.border}40 1px, transparent 1px)`,
        backgroundSize: "80px 80px",
        opacity: 0.4,
      }} />
    </AbsoluteFill>
  );
};

export const Orb: React.FC<{ color: string; x: number; y: number; size: number; delay?: number; label: string; sub: string }>
= ({ color, x, y, size, delay = 0, label, sub }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const pop = spring({ frame: frame - delay, fps, config: { damping: 12, stiffness: 120 } });
  const float = Math.sin((frame - delay) / 18) * 8;
  return (
    <div style={{
      position: "absolute",
      left: x,
      top: y + float,
      transform: `translate(-50%, -50%) scale(${pop})`,
      textAlign: "center",
    }}>
      <div style={{
        width: size,
        height: size,
        borderRadius: "50%",
        background: `radial-gradient(circle, ${color} 0%, ${color}00 70%)`,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        margin: "0 auto",
      }}>
        <div style={{
          width: size * 0.25,
          height: size * 0.25,
          borderRadius: "50%",
          background: color,
          boxShadow: `0 0 ${size * 0.5}px ${color}, 0 0 ${size}px ${color}88`,
        }} />
      </div>
      <div style={{ color, fontWeight: 700, fontSize: 32, marginTop: 16, letterSpacing: 1 }}>{label}</div>
      <div style={{ color: COLORS.muted, fontSize: 18, fontWeight: 500, marginTop: 4, textTransform: "uppercase", letterSpacing: 2 }}>{sub}</div>
    </div>
  );
};
